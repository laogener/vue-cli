import request from '@/utils/request'

// 新增神秘礼包
export function saveSecretRuleCfg(data) {
  return request({
    url: '/score/secretRuleCfg/saveSecretRuleCfg',
    method: 'post',
    server: 'server1',
    data
  })
}
// 删除神秘礼包配置
export function removeSecretRuleCfg(data) {
  return request({
    url: '/score/secretRuleCfg/removeSecretRuleCfg',
    method: 'post',
    server: 'server1',
    data
  })
}
// 修改神秘礼包配置
export function updateSecretRuleCfg(data) {
  return request({
    url: '/score/secretRuleCfg/updateSecretRuleCfg',
    method: 'post',
    server: 'server1',
    data
  })
}
// 查询神秘礼包-分页
export function findSecretRuleCfgPage(data) {
  return request({
    url: '/score/secretRuleCfg/findSecretRuleCfgPage',
    method: 'post',
    server: 'server1',
    data
  })
}
