import request from '@/utils/request'

// 查询推荐商品-分页
export function listRecommendCfgPage(data) {
  return request({
    url: '/admin/recommend/listRecommendCfgPage',
    method: 'post',
    server: 'server2',
    data
  })
}
// 修改推荐商品
export function updateRecommendCfg(data) {
  return request({
    url: '/admin/recommend/updateRecommendCfg',
    method: 'post',
    server: 'server2',
    data
  })
}
// 添加推荐商品
export function saveRecommendCfg(data) {
  return request({
    url: '/admin/recommend/saveRecommendCfg',
    method: 'post',
    server: 'server2',
    data
  })
}
// 删除推荐商品
export function delRecommendCfg(data) {
  return request({
    url: '/admin/recommend/delRecommendCfg',
    method: 'post',
    server: 'server2',
    data
  })
}
// 查询商品分类
export function listProductType(data) {
  return request({
    url: '/web/type/listProductType',
    method: 'post',
    server: 'server2',
    data
  })
}
// 查询商品
export function listProduct(data) {
  return request({
    url: '/admin/product/listProduct',
    method: 'post',
    server: 'server2',
    data
  })
}
