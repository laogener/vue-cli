import request from '@/utils/request'

export function login(data) {
  return request({
    url: '/score/admin/login',
    method: 'post',
    server: 'server1',
    data
  })
}

export function logout(data) {
  return request({
    url: '/score/admin/logout',
    method: 'post',
    server: 'server1',
    data
  })
}

