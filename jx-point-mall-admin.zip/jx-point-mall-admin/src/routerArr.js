const routerArr = [
  { id: 6, menuCode: 'task', menuIcon: 'icon', menuName: '任务管理', menuPath: '/task', parentId: 0 },
  { id: 15, menuCode: 'task-manage', menuIcon: 'icon', menuName: '任务管理', menuPath: 'task-manage', parentId: 6 },

  { id: 1, menuCode: 'attendance-manage', menuIcon: 'icon', menuName: '签到管理', menuPath: '/attendance', parentId: 0 },
  { id: 2, menuCode: 'daily-check-in', menuIcon: 'icon', menuName: '日常签到管理', menuPath: 'daily-check-in', parentId: 1 },
  { id: 3, menuCode: 'points-record-query', menuIcon: 'icon', menuName: '积分记录查询', menuPath: 'points-record-query', parentId: 1 },
  // { id: 4, menuCode: 'mystery-package', menuIcon: 'icon', menuName: '神秘礼包管理', menuPath: 'mystery-package', parentId: 1 },
  // { id: 5, menuCode: 'winners-list', menuIcon: 'icon', menuName: '神秘礼包中奖列表', menuPath: 'winners-list', parentId: 1 },
  { id: 6, menuCode: 'holiday-activities', menuIcon: 'icon', menuName: '节假日活动管理', menuPath: 'holiday-activities', parentId: 1 },

  { id: 7, menuCode: 'goods-classify-manage', menuIcon: 'icon', menuName: '商品分类管理', menuPath: '/goods-classify', parentId: 0 },
  { id: 16, menuCode: 'goods-classify', menuIcon: 'icon', menuName: '商品分类管理', menuPath: 'goods-classify', parentId: 7 },

  { id: 8, menuCode: 'goods', menuIcon: 'icon', menuName: '商品管理', menuPath: '/goods-manage', parentId: 0 },
  { id: 18, menuCode: 'goods-manage', menuIcon: 'icon', menuName: '商品管理', menuPath: 'goods-manage', parentId: 8 },

  { id: 9, menuCode: 'home-content', menuIcon: 'icon', menuName: '首页内容配置', menuPath: '/home-content', parentId: 0 },
  { id: 11, menuCode: 'focus-map', menuIcon: 'icon', menuName: '焦点图管理', menuPath: 'focus-map', parentId: 9 },
  // { id: 12, menuCode: 'flash-purchase', menuIcon: 'icon', menuName: '闪购管理', menuPath: 'flash-purchase', parentId: 9 },
  { id: 13, menuCode: 'classified-recommend', menuIcon: 'icon', menuName: '分类推荐管理', menuPath: 'classified-recommend', parentId: 9 },

  { id: 14, menuCode: 'order', menuIcon: 'icon', menuName: '订单管理', menuPath: '/order-manage', parentId: 0 },
  { id: 17, menuCode: 'order-manage', menuIcon: 'icon', menuName: '订单管理', menuPath: 'order-manage', parentId: 14 },

  { id: 18, menuCode: 'integralDes', menuIcon: 'icon', menuName: '积分说明', menuPath: '/integral-description', parentId: 0 },
  { id: 19, menuCode: 'integral-description', menuIcon: 'icon', menuName: '积分说明', menuPath: 'integral-description', parentId: 18 },
]
export default routerArr
