import request from '@/utils/request'


// 查询神秘礼包-分页
export function getUserScoreLog(data) {
  return request({
    url: '/score/getUserScoreLog',
    method: 'post',
    server: 'server1',
    data
  })
}
