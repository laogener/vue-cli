<template>
  <div class="app-container">
    <el-row>
      <el-form ref="form" :inline="true" size="small" class="has-report-form-search">
        <el-form-item>
          <el-input v-model="queryList.title" placeholder="标题" clearable/>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="query('btn')">搜索</el-button>
          <el-button type="primary" icon="el-icon-plus" @click="addOrModify()">新增</el-button>
        </el-form-item>
      </el-form>
    </el-row>
    <el-table v-loading="listLoading" :data="list" :height="tableHeight + 70" border fit highlight-current-row
              style="width: 100%;">
      <el-table-column type="index" width="50"/>
      <el-table-column prop="title" label="标题" show-overflow-tooltip align="center"/>
      <el-table-column prop="pcRemark" label="PC端描述" show-overflow-tooltip align="center"/>
      <el-table-column prop="wapRemark" label="WAP端描述" show-overflow-tooltip align="center"/>
      <el-table-column prop="sortNo" label="排序编号" show-overflow-tooltip align="center"/>
      <el-table-column prop="lastUpdateTime" label="修改时间" show-overflow-tooltip align="center"/>

      <el-table-column label="操作" align="center" width="150px">
        <template slot-scope="scope">
          <el-button type="primary" size="small" @click="addOrModify(scope.row)">修改</el-button>
          <el-button type="primary" size="small" @click="del(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <Pagination
      v-show="total>0"
      :page-sizes="[20,50,100,200,500]"
      :total="total"
      :page.sync="queryList.pageNumber"
      :limit.sync="queryList.pageSize"
      @pagination="query"
    />
    <!--      新增 修改 弹窗-->
    <el-dialog :title="dialog.title" :visible.sync="dialog.dialogFormVisible" width="1000px">
      <el-form :model="form" label-width="150px">
        <el-form-item label="标题:">
          <el-input v-model="form.title" clearable/>
        </el-form-item>
        <el-form-item label="排序:">
          <el-input v-model="form.sortNo" type="number" clearable/>
        </el-form-item>
        <el-form-item label="PC端描述：">
          <Kindeditor
            v-model="form.pcRemark"
            :height="230"
            :data="{ siteCode: getSiteCode,fileDir:'integral'}"
          ></Kindeditor>
        </el-form-item>
        <el-form-item label="WAP端描述：">
          <Kindeditor
            v-model="form.wapRemark"
            :height="230"
            :data="{ siteCode: getSiteCode,fileDir:'integral'}"
          ></Kindeditor>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialog.dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addOrModifySubmit">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
    import {
        saveHelpCfg,
        delHelpCfg,
        updateHelpCfg,
        listHelpCfgPage
    } from '@/api/modules/integral-description'
    import Pagination from '@/components/Pagination'
    import Kindeditor from '@/components/Kindeditor/index.vue';
    import {getSiteCode} from '@/utils/auth'

    export default {
        name: 'integral-description',
        components: {Pagination, Kindeditor},
        computed: {

            getSiteCode() {
                return getSiteCode()
            }
        },
        data() {
            return {

                queryList: {
                    title: '',
                    pageSize: 20,
                    pageNumber: 1
                },
                list: [],
                listLoading: false,
                total: 0,
                dialog: {
                    type: '',
                    title: '',
                    dialogFormVisible: false
                },

                checkAll: false,
                checkedGroup: [],
                isIndeterminate: true,

                form: {
                    title: '',
                    sortNo: '',
                    pcRemark: '',
                    wapRemark: '',
                }
            }
        },
        created() {
            this.query()
        },
        methods: {
            query(val) {
                if (val == 'btn') {
                    this.queryList.pageNumber == 1
                }
                this.listLoading = true
                listHelpCfgPage(this.queryList).then(({code, data}) => {
                    this.list = data.list
                    this.total = data.total
                }).catch(e => {
                    this.$message.error(e.msg)
                }).finally(() => (this.listLoading = false))
            },
            // 新增 修改 任务设置 按钮
            addOrModifySubmit() {
                if (!this.form.title) {
                    this.$message.info('请输入标题')
                    return false
                }

                if (this.form.sortNo === '') {
                    this.$message.info('请输入排序')
                    return false
                }
                if (!this.form.pcRemark) {
                    this.$message.info('请输入PC端描述')
                    return false
                }
                if (!this.form.wapRemark) {
                    this.$message.info('请输入WAP端描述')
                    return false
                }

                let api = null, query = this.form;
                if (this.dialog.type == 'modify') {
                    api = updateHelpCfg
                } else {
                    api = saveHelpCfg
                }
                api(query).then(({code}) => {
                    code == 200 && this.$message.success(this.dialog.title + '成功') && this.query()
                }).catch(e => {
                    this.$message.error(e.msg)
                })
                this.dialog.dialogFormVisible = false
            },
            // 新增 修改 任务设置 弹窗
            addOrModify(row) {
                if (row) {
                    this.dialog.type = 'modify'
                    this.dialog.title = '修改'
                    Object.assign(this.form,row)
                } else {
                    this.resetFrom()
                    this.dialog.type = 'add'
                    this.dialog.title = '新增'
                }
                this.dialog.dialogFormVisible = true
            },
            resetFrom() {
                delete this.form.id
                this.form.title = '',
                this.form.pcRemark = '',
                this.form.wapRemark = '',
                this.form.sortNo = ''
            },
            del(row) {
                this.$confirm('确认删除该条数据？', '提示',{
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning',
                    }).then(() => {
                    delHelpCfg({id: row.id}).then(({code}) => {
                        code == 200 && this.$message.success('删除成功') && this.query()
                    }).catch(e => {
                        this.$message.error('删除失败')
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    })
                })
            },
            // 上传图片
            handleSuccess(res, file, fileList) {
                this.form.imgUrl = res.data || ''
            },
            onUploadFileError(err, file, fileList) {
                this.$message.error(err.msg || '上传图片失败')
            },
            beforeAvatarUpload(file) {
                const isLt5M = file.size / 1024 / 1024 < 5;

                if (!isLt5M) {
                    this.$message.error('上传头像图片大小不能超过 5MB!');
                }
                return isLt5M;
            },
            // checkbox
            handleCheckAllChange(val) {
                this.checkedGroup = val ? this.options : []
                this.isIndeterminate = false
            },
            handleCheckedChange(value) {
                const checkedCount = value.length
                this.checkAll = checkedCount === this.options.length
                this.isIndeterminate = checkedCount > 0 && checkedCount < this.options.length
            }
        }
    }
</script>

<style scoped>

</style>
