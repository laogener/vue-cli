<template>
  <el-scrollbar wrap-class="scrollbar-wrapper">
    <div :class="{ 'open' : !isCollapse }" class="logo">
      <span class="svg-container">
        <svg-icon icon-class="logo" class="svg-icon icon" />
      </span>
      <span v-show="!isCollapse" class="company-name">金星科技</span>
    </div>
    <div v-show="!isCollapse" class="side-user">{{ name }},欢迎您!</div>
    <el-menu
      :show-timeout="200"
      :default-active="$route.path"
      :collapse="isCollapse"
      mode="vertical"
      text-color="#B3B3B3"
      active-text-color="#62A7FF"
    >
      <sidebar-item
        v-for="(route , index ) in permission_routers"
        :key="`${route.path + index}_key`"
        :item="route"
        :base-path="route.path"
      />
    </el-menu>
  </el-scrollbar>
</template>

<script>
import { mapGetters } from 'vuex'
import SidebarItem from './SidebarItem'

export default {
  components: { SidebarItem },
  computed: {
    ...mapGetters(['permission_routers', 'sidebar', 'name']),
    isCollapse() {
      return !this.sidebar.opened
    }
  }
}
</script>
