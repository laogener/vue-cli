import { constantRouterMap } from '@/router'
import Layout from '@/views/layout/Layout'

function jsonMenuToRouter(menuList) {
  const result = []
  if (menuList && menuList.length) {
    const menuChildList = menuList.filter(item => {
      if (item.parentId === 0) {
        result.push({
          menuId: item.id,
          path: item.menuPath,
          name: item.menuCode,
          component: Layout,
          meta: { menuId: item.id, title: item.menuName, icon: 'excel' },
          children: []
        })
        return false
      }
      return true
    })
    menuChildList.forEach(item => {
      for (let i = 0; i < result.length; i++) {
        if (item.parentId === result[i].menuId) {
          try {
            if (!item.menuPath || !item.menuCode) {
              throw Error('menuPath or menuCode is undefined')
            }
            result[i].children.push({
              menuId: item.id,
              path: item.menuPath,
              name: item.menuCode,
              hidden: item.hidden || false,
              component: () => import(`@/views/modules${result[i].path}/${item.menuPath}/index.vue`),
              meta: { menuId: item.id, title: item.menuName, icon: 'icon', noCache: false }
            })
          } catch (error) {
            console.log('error:' + error)
          }
          break
        }
      }
    })
    result.push({ path: '*', redirect: '/task/task-manage', hidden: true })
  }
  return result
}

const permission = {
  state: {
    routers: constantRouterMap,
    addRouters: []
  },
  mutations: {
    CLEAN_ROUTERS: state => {
      state.addRouters = []
    },
    SET_ROUTERS: (state, routers) => {
      state.addRouters = routers
      state.routers = constantRouterMap.concat(routers)
    }
  },
  actions: {
    cleanRouterAction({ commit }) {
      commit('CLEAN_ROUTERS')
    },
    GenerateRoutes({ commit, rootGetters }) {
      return new Promise(resolve => {
        const accessedRouters = jsonMenuToRouter(JSON.parse(rootGetters.menuList))
        commit('SET_ROUTERS', accessedRouters)
        resolve()
      })
    }
  }
}

export default permission
