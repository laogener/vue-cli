<template>
  <div class="app-container">
    <el-row>
      <el-form ref="form" :inline="true" size="small" class="has-report-form-search">
        <el-form-item>
          <el-input v-model="queryList.name" placeholder="商品名称、型号" clearable/>
        </el-form-item>
        <el-form-item>
          <el-select v-model="queryList.typeNo" placeholder="请选择" style="width: 250px;">
            <el-option
              v-for="item in listProduct"
              :key="item.typeNo"
              :label="item.typeName"
              :value="item.typeNo"/>
          </el-select>
        </el-form-item>

        <el-form-item label="状态:">
          <el-select v-model="queryList.status" placeholder="请选择" style="width: 100px;">
            <el-option label="全部" value=""/>
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"/>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="query('btn')">搜索</el-button>
          <el-button type="primary" icon="el-icon-plus" @click="addOrModify()">新增</el-button>
        </el-form-item>
      </el-form>
    </el-row>
    <el-table v-loading="listLoading" :data="list" :height="tableHeight + 70" border fit highlight-current-row
              style="width: 100%;">
      <el-table-column type="index" width="50"/>
      <el-table-column prop="name" label="名称" show-overflow-tooltip width="150" align="center"/>
      <el-table-column prop="typeName" label="类型名称" show-overflow-tooltip width="100" align="center"/>
      <el-table-column prop="price" label="价格" show-overflow-tooltip width="80" align="center"/>
      <el-table-column prop="status" label="状态" show-overflow-tooltip width="80" align="center">
        <template slot-scope="scope">
          <span v-if="scope.row.status" style="color: #409EFF">启用</span>
          <span v-else style="color: #F56C6C">禁用</span>
        </template>
      </el-table-column>
      <el-table-column prop="membersGroup" label="会员组" show-overflow-tooltip width="150" align="center"/>

      <el-table-column prop="lastUpdateTime" label="修改时间" show-overflow-tooltip width="150" align="center"/>

      <el-table-column prop="signDay" label="图片" align="center">
        <template slot-scope="scope">
          <img v-for="item in scope.row.imgUrl.split(',')" :src="item" alt="" style="height: 80px;margin-right: 10px">
        </template>
      </el-table-column>
<!--      <el-table-column prop="remark" label="备注" show-overflow-tooltip align="center">-->
<!--        <template slot-scope="scope">-->
<!--          <div v-html="scope.row.remark"></div>-->
<!--        </template>-->
<!--      </el-table-column>-->
      <el-table-column label="操作" align="center" width="150" fixed="right">
        <template slot-scope="scope">
          <el-button type="primary" size="small" @click="addOrModify(scope.row)">修改</el-button>
          <el-button type="primary" size="small" @click="del(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <Pagination
      v-show="total>0"
      :page-sizes="[20,50,100,200,500]"
      :total="total"
      :page.sync="queryList.pageNumber"
      :limit.sync="queryList.pageSize"
      @pagination="query"
    />
    <!--      新增 修改 弹窗-->
    <el-dialog :title="dialog.title" :visible.sync="dialog.dialogFormVisible" width="1000px">
      <el-form :model="form" label-width="150px" style="max-height: 500px;overflow: auto">
        <el-form-item label="商品名称:">
          <el-input v-model="form.name" clearable/>
        </el-form-item>

        <el-form-item label="商品分类:">
          <el-select v-model="form.typeNo" placeholder="请选择" style="width: 250px;">
            <el-option
              v-for="item in listProduct"
              :key="item.typeNo"
              :label="item.typeName"
              :value="item.typeNo"/>
          </el-select>
        </el-form-item>
        <el-form-item label="型号:">
          <el-input v-model="form.model" clearable/>
        </el-form-item>
        <el-form-item label="积分数:">
          <el-input v-model="form.price"  type="number" clearable/>
        </el-form-item>
        <el-form-item label="实际金额:">
          <el-input v-model="form.money"  type="number" clearable/>
        </el-form-item> <el-form-item label="类型:">
        <el-radio v-model="form.type" :label="true">虚拟彩金</el-radio>
        <el-radio v-model="form.type" :label="false">实物商品</el-radio>
      </el-form-item>

        <el-form-item label="状态:">
          <el-select v-model="form.status" placeholder="请选择" style="width: 120px;">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"/>
          </el-select>
        </el-form-item>
        <el-form-item label="图片:">
          <template v-if="form.imgUrl">
            <span v-for="item in form.imgUrl.split(',')" class="imgSpan">
              <img :src="item" alt="" class="el-upload-list__item-thumbnail">
              <span style="width: 148px;height: 148px">
                <i class="el-icon-delete" @click="handleRemove(item)"></i>
              </span>

            </span>
          </template>

          <el-upload
            :action="`${uploadHost}/score/signRuleCfg/uploadFile`"
            :show-file-list="false"
            :data="{siteCode: getSiteCode,fileDir:'integral'}"
            :on-success="(value)=> handleSuccess(value,'imgs')"
            :on-error="onUploadFileError"
            :before-upload="beforeAvatarUpload"
            list-type="picture-card"
            class="avatar-uploader"
            v-if="form.imgUrl.split(',').length < 5"
            style="float: left"
          >

            <i class="el-icon-plus avatar-uploader-icon"/>
          </el-upload>
          <span  v-if="form.imgUrl.split(',').length < 4" style="float: left;margin-top: 110px;padding-left: 17px;color: #C0C4CC">分辨率不小于480*480</span>
        </el-form-item>
        <el-form-item label="缩略图:">
          <el-upload
            :action="`${uploadHost}/score/signRuleCfg/uploadFile`"
            :show-file-list="false"
            :data="{siteCode: getSiteCode,fileDir:'integral'}"
            :on-success="(value)=> handleSuccess(value,'img')"
            :on-error="onUploadFileError"
            :before-upload="beforeAvatarUpload2"
            class="avatar-uploader margin-top-15"
          >
            <img v-if="form.smallImg" :src="form.smallImg" height="148" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"/>
          </el-upload>
          <span style="position: relative;top: -44px;left: 165px;color: #C0C4CC">分辨率不小于150*150</span>
        </el-form-item>
        <el-form-item label="关联会员组:">
          <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
<!--          <el-checkbox v-model="checked">游客组</el-checkbox>-->
          <div style="margin: 15px 0;"/>
          <el-checkbox-group v-model="checkedGroup" @change="handleCheckedChange">
            <el-checkbox v-for="item in groupList" :label="item.groupName" :key="item.groupKey"
                         style="width: 160px;margin-left: 0px;margin-right: 10px">{{ item.groupName }}
            </el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="商品详情：">
          <Kindeditor
            v-model="form.remark"
            :height="230"
            :data="{ siteCode: getSiteCode,fileDir:'integral'}"
          ></Kindeditor>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialog.dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addOrModifySubmit">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
    import { getSiteUserGroup} from '@/api/modules/attendance/daily-check-in'
    import {saveProduct, updateProduct, delProduct, listProductPage, listProductType} from '@/api/modules/goods-manage'
    import Pagination from '@/components/Pagination'
    import {getSiteCode} from '@/utils/auth'
    import Kindeditor from '@/components/Kindeditor/index.vue';
    import { HOST_LIST } from '@/config'

    export default {
        name: 'GoodsManage',
        components: {Pagination, Kindeditor},
        computed: {
            uploadHost() {
                return HOST_LIST[process.env.ENV_CONFIG]['server1']
            },
            getSiteCode() {
                return getSiteCode()
            }
        },
        watch: {
            'form.typeNo': {
                immediate: true,
                handler(val) {
                    this.listProduct.map(item => {
                        item.typeNo == val && (this.form.typeName = item.typeName)
                    })
                },
                deep:true
            },

        },
        data() {
            return {
                // checked: true,//游客组
                options: [// 签到天数
                    {value: true, label: '启用'},
                    {value: false, label: '禁用'},
                ],
                queryList: {
                    typeNo: '',
                    status: '',
                    name: '',
                    pageSize: 20,
                    pageNumber: 1
                },
                groupList: [],
                groupListName: [],
                list: [],
                listProduct: [],
                listLoading: false,
                total: 0,
                dialog: {
                    type: '',
                    title: '',
                    dialogFormVisible: false
                },

                dialogImageUrl: '',
                dialogVisible: false,
                disabled: false,

                checkAll: false,
                checkedGroup: [],
                isIndeterminate: true,

                form: {
                    name: '',
                    typeNo: '',
                    typeName: '',
                    model: '',
                    price: '',
                    money: '',
                    type: true,
                    status: '',
                    imgUrl: '',
                    smallImg: '',
                    remark: '',
                    membersGroup: '',
                    sortNo: ''
                }
            }
        },
        created() {
            this.query()
            this.listProductType()
        },
        methods: {

            async query(val) {
                if (val == 'btn') {
                    this.queryList.pageNumber == 1
                }
                await this.getSiteUserGroup();
                this.listLoading = true;
                listProductPage(this.queryList).then(({code, data}) => {
                    data.list.forEach( item3 => {
                        item3.membersGroup = this.groupFmt(item3.membersGroup)
                    })
                    this.list = data.list
                    this.total = data.total
                }).catch(e => {
                     this.$message.error(e.msg)
                }).finally(() => (this.listLoading = false))
            },
            groupFmt(value) {
                let group = [];

                if(value == 'default'){
                    this.groupList.map(item2 => {
                        group.push(item2.groupName)
                    })
                }else {
                    let membersGroup = value.split(',');
                    membersGroup.map(item => {
                        this.groupList.map(item2 => {
                            if (item == item2.groupKey) {
                                group.push(item2.groupName)
                            }
                        })

                    })
                }
                return group.join(',')
            },
            groupFmt2() {
                let group = [];

                this.checkedGroup.map(item => {
                    this.groupList.map(item2 => {
                        if (item == item2.groupName) {
                            group.push(item2.groupKey)
                        }
                    })
                })
                let index = group.indexOf(-1);
                index > -1 && group.splice(index,1) && (group = group.concat(-1))
                console.log(group)
                return group.join(',')
            },
            // 新增 修改 任务设置 按钮
            addOrModifySubmit() {
                if (!this.form.name) {
                    this.$message.info('请输入商品名称')
                    return false
                }
                if (!this.form.model) {
                    this.$message.info('请输入型号')
                    return false
                }
                if (!this.form.price) {
                    this.$message.info('请输入积分数')
                    return false
                }
                if (!this.form.money) {
                    this.$message.info('请输入实际金额')
                    return false
                }
                if (!this.form.imgUrl) {
                    this.$message.info('请上传图片')
                    return false
                }
                if (!this.form.smallImg) {
                    this.$message.info('请上传缩略图')
                    return false
                }

                this.form.membersGroup = this.groupFmt2();
                if (!this.form.membersGroup) {
                    this.$message.info('请选择关联用户组')
                    return false
                }
                let api = null, query = this.form;
                if (this.dialog.type == 'modify') {
                    api = updateProduct
                } else {
                    api = saveProduct
                }
                api(query).then(({code}) => {
                    code == 200 && this.$message.success(this.dialog.title + '成功') && this.query()
                }).catch(e => {
                    this.$message.error(e.msg)
                })
                this.dialog.dialogFormVisible = false
            },
            // 新增 修改 任务设置 弹窗
            addOrModify(row) {
                if (row) {
                    this.dialog.type = 'modify'
                    this.dialog.title = '修改商品'
                    this.checkedGroup = row.membersGroup.split(',')
                    Object.assign(this.form,row)
                } else {
                    this.resetFrom()
                    this.dialog.type = 'add'
                    this.checkedGroup =['游客组']
                    this.dialog.title = '新增商品'
                }
                this.dialog.dialogFormVisible = true
            },
            resetFrom() {
                delete this.form.id
                this.form.name = ''
                this.form.typeNo = this.listProduct[0].typeNo
                this.form.model = ''
                this.form.price = ''
                this.form.money = ''
                this.form.type = true
                this.form.status = true
                this.form.imgUrl = ''
                this.form.smallImg = ''
                this.form.remark = ''
                this.form.sortNo = ''
                this.checkedGroup = []
                this.isIndeterminate = true
            },
            del(row) {
                this.$confirm(
                    `<div>
        <div style="display: flex"><span style="width: 160px;text-align: right">商品ID：</span>${row.productNo}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">商品名称：</span>${row.name}</div>
     </div>`
                    , '确认删除？', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning',
                        dangerouslyUseHTMLString: true,
                        center: true
                    }).then(() => {
                    delProduct({productNo: row.productNo}).then(({code}) => {
                        code == 200 && this.$message.success('删除成功') && this.query()
                    }).catch(e => {
                        this.$message.error('删除失败')
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    })
                })
            },

            listProductType(){
                listProductType().then(({code, data}) => {
                    this.listProduct = data
                }).catch(e => {
                     this.$message.error(e.msg)
                })
            },
            // 获取用户组接口
            getSiteUserGroup() {
                return new Promise(resolve => {
                    getSiteUserGroup().then(({code, data}) => {
                        code == 200 && (this.groupList = data.concat([{groupKey:-1,groupName:'游客组'}]))
                        this.groupListName =  this.groupList.map(item => item.groupName)
                        resolve()
                    })
                })
            },
            // 上传图片
            handleSuccess(res, item) {
                if(item == 'imgs'){
                    !this.form.imgUrl ? (this.form.imgUrl = res.data) : (this.form.imgUrl += ',' + res.data)
                }else {
                    this.form.smallImg = res.data || ''
                }
            },
            onUploadFileError(err, file, fileList) {
                this.$message.error(err.msg || '上传图片失败')
            },
            handleRemove(item) {
                let imgUrl = [];
                this.form.imgUrl.indexOf(',') > 0 ? (imgUrl = this.form.imgUrl.split(',') ): imgUrl.push(item)
                const index = imgUrl.indexOf(item);
                imgUrl.splice(index, 1);
                (imgUrl.length == 0) ? (this.form.imgUrl = '') : (imgUrl.length == 1)  ? (this.form.imgUrl = imgUrl[0]) : (this.form.imgUrl = imgUrl.join(','))
            },
            beforeAvatarUpload(file) {
                const isLt5M = file.size / 1024 / 1024 < 5;

                if (!isLt5M) {
                    this.$message.error('上传头像图片大小不能超过 5MB!');
                }
                return isLt5M;
            },
            beforeAvatarUpload2(file) {
                let _this = this
                return new Promise((resolve, reject) => {
                    let isLt2M = file.size / 1024 / 1024 < 2 // 判定图片大小是否小于10MB
                    if(!isLt2M) {
                        _this.$message.error('上传头像图片大小不能超过 2MB!');
                        reject()
                    }
                    let image = new Image(), resultBlob = '';
                    image.src = URL.createObjectURL(file);
                    image.onload = () => {
                        if(image.width > 200 || image.height > 200){
                            // 调用方法获取blob格式，方法写在下边
                            resultBlob = _this.createReader(image);
                            resolve(resultBlob)
                        }else {
                            resolve(file)
                        }

                    }
                    image.onerror = () => {
                        reject()
                    }
                })
            },
             zip(file){
                return this.createReader(file);
            },
            // checkbox
            handleCheckAllChange(val) {
                this.checkedGroup = val ? this.groupListName : []
                this.isIndeterminate = false
            },
            handleCheckedChange(value) {
                const checkedCount = value.length
                this.checkAll = checkedCount === this.groupListName.length
                this.isIndeterminate = checkedCount > 0 && checkedCount < this.groupListName.length
            },
            createReader(img) {
                const w = 200;
                const h = 200;
                //生成canvas
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                // 创建属性节点
                const anw = document.createAttribute("width");
                anw.nodeValue = w;
                const anh = document.createAttribute("height");
                anh.nodeValue = h;
                canvas.setAttributeNode(anw);
                canvas.setAttributeNode(anh);

                //铺底色 PNG转JPEG时透明区域会变黑色
                ctx.fillStyle = "#fff";
                ctx.fillRect(0, 0, w, h);

                ctx.drawImage(img, 0, 0, w, h);
                // quality值越小，所绘制出的图像越模糊
                const base64 = canvas.toDataURL('image/jpeg'); //图片格式jpeg或webp可以选0-1质量区间

                // 返回base64转blob的值
                let arr = base64.split(','), mime = arr[0].match(/:(.*?);/)[1], bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
                while(n--){
                    u8arr[n] = bstr.charCodeAt(n);
                }
                return new File( [u8arr], 'a.png' , {type : 'image/jpeg'});
            }
        }
    }
</script>

<style scoped>
.imgSpan{
  display: inline-block;
  position: relative;
  float: left;
}
.imgSpan:hover span{
  display: block;
}
  .imgSpan img{
    margin-right: 10px;
    height: 148px;
    width: 148px
  }
.imgSpan span{
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  background-color: rgba(0,0,0,.5);
  text-align: center;
  line-height: 161px;
  display: none;
}
.imgSpan span i{
    font-size: 20px;
  color: #ffffff;
}
</style>
