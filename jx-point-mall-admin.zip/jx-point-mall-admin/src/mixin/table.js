const tableMixin = {
  data() {
    return {
      config: {
        list: '',
        add: '',
        del: '',
        update: ''
      },
      list: [],
      total: 0,
      pageNum: 0,
      pageSize: 10,
      listQuery: {},
      listLoading: false,
      dialogStatus: '',
      dialogFormVisible: false,
      form: {},
      originalForm: {},
      textMap: {
        update: 'Edit',
        create: 'Create'
      }
    }
  },
  created() {
    this.getDataList()
  },
  mounted() {
    this.copyForm()
  },
  methods: {
    copyForm() {
      if (this.config.form) {
        this.form = this.originalForm = JSON.parse(JSON.stringify(this.config.form))
      }
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.getDataList()
    },
    handleCurrentChange(val) {
      this.pageNum = val
      this.getDataList()
    },
    handleFilter() {
      this.pageNum = 1
      this.getDataList()
    },
    getDataList() {
      const _this = this
      _this.listLoading = true
      const query = Object.assign({ pageNum: _this.pageNum, pageSize: _this.pageSize }, _this.listQuery)
      if (_this.config.list) {
        _this.config.list(query).then(res => {
          _this.listLoading = false
          const { currentStatus, currentData } = res
          if (currentStatus === '200') {
            const { list, total } = currentData
            _this.list = list
            _this.total = total
          }
        }).catch(() => {
          _this.listLoading = false
        })
      }
    },
    resetForm() {
      this.form = Object.assign({}, this.originalForm)
    },
    handleCreate() {
      this.resetForm()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    handleUpdate(row) {
      this.form = Object.assign({}, row)
      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    createData() {
      const _this = this
      _this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          _this.config.add(_this.form).then(({ currentStatus }) => {
            if (currentStatus === '200') {
              _this.$message({ message: '添加成功', type: 'success' })
              _this.dialogFormVisible = false
              _this.getDataList()
            }
          }).catch(() => {
            _this.$message({ message: '添加失败', type: 'error' })
          })
        }
      })
    },
    updateData() {
      if (this.config.update) {
        this.config.update(this.form).then(({ currentStatus }) => {
          if (currentStatus === '200') {
            this.$message({ message: '修改成功', type: 'success' })
            this.dialogFormVisible = false
            this.getDataList()
          }
        }).catch(() => {
          this.$message({ message: '修改失败', type: 'error' })
        })
      }
    },
    handleDelete(row) {
      if (this.config.del) {
        this.config.del({ id: row.id }).then(({ currentStatus }) => {
          if (currentStatus === '200') {
            this.$message({ message: '删除成功', type: 'success' })
            this.getDataList()
          }
        })
      }
    }
  }
}

export default tableMixin
