<template>
  <div class="app-container">
    <el-row>
      <el-form ref="form" :inline="true" size="small" class="has-report-form-search">
        <el-form-item label="签到天数:">
          <el-select v-model="queryList.signDay" placeholder="请选择" style="width: 100px;">
            <el-option label="全部" value=""/>
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"/>
          </el-select>
        </el-form-item>
        <el-form-item label="用户组:">
          <el-select v-model="queryList.groupSetName" placeholder="请选择" style="width: 200px;">
            <el-option
              v-for="item in groupList"
              :key="item.groupKey"
              :label="item.groupName"
              :value="item.groupName"/>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="query('btn')">搜索</el-button>
          <el-button type="primary" icon="el-icon-plus" @click="addOrModify()">新增</el-button>
        </el-form-item>
      </el-form>
    </el-row>
    <el-table v-loading="listLoading" :data="list" :height="tableHeight + 70" border fit highlight-current-row
              style="width: 100%;">
      <el-table-column prop="signDay" label="签到天数" show-overflow-tooltip align="center" width="80"/>
      <el-table-column prop="minShow" label="最小展示值" show-overflow-tooltip align="center" width="90"/>
      <el-table-column prop="maxShow" label="最大展示值" show-overflow-tooltip align="center" width="90"/>
      <el-table-column prop="minReal" label="最小实际值" show-overflow-tooltip align="center" width="90"/>
      <el-table-column prop="maxReal" label="最大实际值" show-overflow-tooltip align="center" width="90"/>
      <el-table-column prop="itemPic" label="图片" align="center" width="80">
        <template slot-scope="scope">
          <img :src="scope.row.itemPic" alt="" width="50">
        </template>
      </el-table-column>
      <!--      <el-table-column prop="groupSet" label="用户组id" show-overflow-tooltip align="center"/>-->
      <el-table-column prop="groupSetName" label="用户组名称" show-overflow-tooltip align="center"/>
      <el-table-column prop="" label="创建时间" show-overflow-tooltip align="center" width="150">
        <template slot-scope="scope">{{ scope.row.createTime | timeFmtFilter }}</template>
      </el-table-column>
      <el-table-column prop="createBy" label="创建者" show-overflow-tooltip align="center" width="90"/>
      <el-table-column prop="" label="修改时间" show-overflow-tooltip align="center" width="150">
        <template slot-scope="scope">{{ scope.row.updateTime | timeFmtFilter }}</template>
      </el-table-column>
      <el-table-column prop="updateBy" label="修改账号" show-overflow-tooltip align="center" width="90"/>
      <el-table-column label="操作" align="center" width="150px">
        <template slot-scope="scope">
          <el-button type="primary" size="small" @click="addOrModify(scope.row)">修改</el-button>
          <el-button type="primary" size="small" @click="del(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <Pagination
      v-show="total>0"
      :page-sizes="[20,50,100,200,500]"
      :total="total"
      :page.sync="queryList.pageNum"
      :limit.sync="queryList.pageSize"
      @pagination="query"
    />
    <!--      新增 修改 弹窗-->
    <el-dialog :title="dialog.title" :visible.sync="dialog.dialogFormVisible" width="750px">
      <el-form :model="form" label-width="150px">

        <el-form-item label="签到循环天数:">
          <el-select v-model="form.signDay" placeholder="请选择" style="width: 120px;">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"/>
          </el-select>
        </el-form-item>
        <el-form-item label="展示给用户的奖励:">
          <el-input v-model.number="form.minShow" placeholder="最小值" style="width: 120px;" type="number" clearable/>
          <el-input v-model.number="form.maxShow" placeholder="最大值" style="width: 120px;" type="number" clearable/>
        </el-form-item>
        <el-form-item label="实际奖励积分数:">
          <el-input v-model.number="form.minReal" placeholder="最小值" style="width: 120px;" type="number" clearable/>
          <el-input v-model.number="form.maxReal" placeholder="最大值" style="width: 120px;" type="number" clearable/>
        </el-form-item>
        <el-form-item label="图片:">
          <el-upload
            :action="`${uploadHost}/score/signRuleCfg/uploadFile`"
            :show-file-list="false"
            :data="{siteCode: getSiteCode,fileDir:'sign'}"
            :on-success="handleSuccess"
            :on-error="onUploadFileError"
            class="avatar-uploader margin-top-15"
          >
            <img v-if="form.itemPic" :src="form.itemPic" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"/>
          </el-upload>
        </el-form-item>
        <el-form-item label="关联用户组:">
          <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选
          </el-checkbox>
          <div style="margin: 15px 0;"/>
          <el-checkbox-group v-model="checkedGroup" @change="handleCheckedChange">
            <el-checkbox v-for="item in groupList" :label="item.groupName" :key="item.groupKey"
                         style="width: 160px;margin-left: 0px;margin-right: 10px">{{ item.groupName }}
            </el-checkbox>
          </el-checkbox-group>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialog.dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addOrModifySubmit">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
    import {
        saveSignRuleCfg,
        removeSignRuleCfg,
        updateSignRuleCfg,
        findSignRuleCfgPage,
        getSiteUserGroup
    } from '@/api/modules/attendance/daily-check-in'
    import Pagination from '@/components/Pagination'
    import {getAccount, getSiteCode} from '@/utils/auth'
    import {formatDate} from '@/utils'
    import { HOST_LIST } from '@/config'


    export default {
        name: 'DailyCheckIn',
        components: {Pagination},
        filters: {
            timeFmtFilter(value) {
                return formatDate(new Date(value), 'yyyy-MM-dd hh:mm:ss')
            }
        },
        computed: {
            uploadHost() {
                return HOST_LIST[process.env.ENV_CONFIG]['server1']
            },
            getSiteCode() {
                return getSiteCode()
            }
        },
        data() {
            return {
                options: [// 签到天数
                    // {value: '', label: '全部'},
                    {value: 1, label: '一天'},
                    {value: 2, label: '两天'},
                    {value: 3, label: '三天'},
                    {value: 4, label: '四天'},
                    {value: 5, label: '五天'},
                    {value: 6, label: '六天'},
                    {value: 7, label: '七天'}
                ],
                queryList: {
                    signDay: '',
                    groupSetName: '',
                    pageSize: 20,
                    pageNum: 1
                },
                groupList: [],
                groupListName: [],
                list: [],
                listLoading: false,
                total: 0,
                dialog: {
                    type: '',
                    title: '',
                    dialogFormVisible: false
                },
                checkAll: false,
                checkedGroup: [],
                isIndeterminate: true,

                form: {
                    signDay: '',
                    minShow: '',
                    maxShow: '',
                    minReal: '',
                    maxReal: '',
                    itemPic: '',
                    groupSet: '',
                    groupSetName: '',
                    createBy: '',
                    updateBy: '',
                }
            }
        },

        created() {
            this.getSiteUserGroup()
            this.query()
        },
        methods: {
            query(val) {
                if (val == 'btn') {
                    this.queryList.pageNum == 1
                }
                this.listLoading = true
                findSignRuleCfgPage(this.queryList).then(({code, data}) => {
                    this.list = data.list
                    this.total = data.total
                }).catch(e => {
                     this.$message.error(e.msg)
                }).finally(() => (this.listLoading = false))
            },

            // 新增 修改 任务设置 按钮
            addOrModifySubmit() {
                if (!this.form.signDay) {
                    this.$message.info('请选择具体的签到循环天数')
                    return false
                }
                if (!this.form.itemPic) {
                    this.$message.info('请上传图片')
                    return false
                }
                if (this.checkedGroup.length == 0) {
                    this.$message.info('请选择关联用户组')
                    return false
                }

                this.checkedGroup.map((item, index) => {
                    if (index == 0) {
                        this.form.groupSetName = item
                    } else {
                        this.form.groupSetName += ',' + item
                    }
                    this.groupList.map(item2 => {
                        if (item == item2.groupName) {
                            if (index == 0) {
                                this.form.groupSet = item2.groupKey
                            } else {
                                this.form.groupSet += ',' + item2.groupKey
                            }
                        }
                    })
                })

                this.form.createBy = getAccount()
                this.form.updateBy = getAccount()
                let api = null, query = this.form;
                if (this.dialog.type == 'modify') {
                    api = updateSignRuleCfg
                } else {
                    api = saveSignRuleCfg
                }
                api(query).then(({code}) => {
                    code == 200 && this.$message.success(this.dialog.title + '成功') && this.query()
                }).catch(e => {
                    this.$message.error(e.msg)
                })
                this.dialog.dialogFormVisible = false
            },
            // 新增 修改 任务设置 弹窗
            addOrModify(row) {
                if (row) {
                    this.dialog.type = 'modify'
                    this.dialog.title = '修改规则'
                    this.checkedGroup = row.groupSetName.split(',')
                    Object.assign(this.form,row)
                } else {
                    this.resetFrom();
                    this.checkedGroup = []
                    this.dialog.type = 'add'
                    this.dialog.title = '新增规则'
                }
                this.dialog.dialogFormVisible = true
            },
            resetFrom() {
                delete this.form.id
                this.form.signDay = ''
                this.form.minShow = ''
                this.form.maxShow = ''
                this.form.minReal = ''
                this.form.maxReal = ''
                this.form.itemPic = ''
                this.form.groupSet = ''
                this.form.groupSetName = ''
                this.form.createBy = ''
                this.form.updateBy = ''
                this.isIndeterminate = true
            },
            del(row) {
                console.log(row)
                this.$confirm(
                    `<div>
        <div style="display: flex"><span style="width: 160px;text-align: right">ID：</span>${row.id}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">签到天数：</span>${row.signDay}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">用户组：</span>${row.groupSetName}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">实际奖励：</span>${row.minReal} - ${row.maxReal}积分</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">展示给用户的奖励：</span>${row.minShow} - ${row.maxShow}积分</div>
      </div>`
                    , '确认删除？', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning',
                        dangerouslyUseHTMLString: true,
                        center: true
                    }).then(() => {
                    removeSignRuleCfg(row).then(({code}) => {
                        code == 200 && this.$message.success('删除成功') && this.query()
                    }).catch(e => {
                        this.$message.error('删除失败')
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    })
                })
            },
            // 获取用户组接口
            getSiteUserGroup() {
                getSiteUserGroup().then(({code, data}) => {
                    code == 200 && (this.groupList = data)
                    this.groupListName = data.map(item => item.groupName)
                }).catch(e => {
                     this.$message.error(e.msg)
                })
            },
            // 上传图片
            handleSuccess(res, file, fileList) {
                this.form.itemPic = res.data || ''
            },
            onUploadFileError(err, file, fileList) {
                this.$message.error(err.msg || '上传图片失败')
            },
            // checkbox
            handleCheckAllChange(val) {
                this.checkedGroup = val ? this.groupListName : []
                this.isIndeterminate = false
            },
            handleCheckedChange(value) {
                const checkedCount = value.length
                this.checkAll = checkedCount === this.groupListName.length
                this.isIndeterminate = checkedCount > 0 && checkedCount < this.groupListName.length
            }
        }
    }
</script>

<style scoped>

</style>
