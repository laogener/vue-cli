<template>
  <div class="app-container">
    <div class="filter-container">
      <el-input v-model="listQuery.account" class="small-width filter-item" placeholder="账号" @keyup.enter.native="handleFilter"/>
      <el-button v-waves class="filter-item" type="primary" icon="el-icon-search" @click="handleFilter">查询</el-button>
      <el-button class="filter-item" style="margin-left: 10px;" type="primary" icon="el-icon-edit" @click="handleCreate">添加下属代理</el-button>
    </div>
    <el-table v-loading="listLoading" :data="list" element-loading-text="loading" border fit highlight-current-row style="width: 100%">
      <el-table-column type="index" width="50"/>
      <el-table-column align="center" label="账号">
        <template slot-scope="scope">
          <span>{{ scope.row.payAccount }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="发展详情">
        <template slot-scope="scope">
          <span>{{ scope.row.siteCode }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="状态">
        <template slot-scope="scope">
          <span>{{ scope.row.accountMode }}</span>
        </template>
      </el-table-column>
      <el-table-column align="left" label="登录次数">
        <template slot-scope="scope">
          <span>{{ scope.row.accountStatus }}</span>
        </template>
      </el-table-column>
      <el-table-column align="left" label="注册时间">
        <template slot-scope="scope">
          <span>{{ scope.row.accountStatus }}</span>
        </template>
      </el-table-column>
      <el-table-column align="left" label="最后登录">
        <template slot-scope="scope">
          <span>{{ scope.row.accountStatus }}</span>
        </template>
      </el-table-column>
    </el-table>

    <div class="pagination-container">
      <el-pagination
        :current-page="pageNum"
        :page-sizes="[10,20,30,50]"
        :page-size="pageSize"
        :total="total"
        background
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"/>
    </div>

    <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible">
      <el-form ref="dataForm" :rules="rules" :model="form" label-position="right" label-width="120px">
        <el-row>
          <el-col :span="10">
            <el-form-item label="登录名" prop="pay_account">
              <el-input v-model="form.payAccount"/>
            </el-form-item>
          </el-col>
          <el-col :span="14">
            <el-form-item label="登录密码" prop="site_code">
              <el-input v-model="form.siteCode"/>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="确认密码" prop="day_max_count">
              <el-input v-model="form.dayMaxCount"/>
            </el-form-item>
          </el-col>
          <el-col :span="14">
            <el-form-item label="验证码" prop="day_max_count">
              <el-input v-model="form.dayMaxCount"/>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">{{ $t('table.cancel') }}</el-button>
        <el-button v-if="dialogStatus==='create'" type="primary" @click="createData">{{ $t('table.confirm') }}</el-button>
        <el-button v-else type="primary" @click="updateData">{{ $t('table.confirm') }}</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import waves from '@/directive/waves'
import { list, add, update, del } from '@/api/business/pay/account-manage'
import tableMixin from '@/mixin/table'

export default {
  name: 'AgentNextLevel',
  directives: {
    waves
  },
  mixins: [tableMixin],
  data() {
    return {
      rules: {},
      config: {
        add: add,
        del: del,
        update: update,
        list: list,
        form: {
          payAccount: '',
          siteCode: '',
          accountMode: 0,
          dayMaxCount: 0,
          dayMaxAmount: 0.00,
          maxAmount: 0.00,
          dayWarningCount: 0,
          dayWarningAmount: 0.00,
          warningAmount: 0.00,
          accountInitAmount: 0.00,
          accountActiveAmount: 0.00
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
  .demo-table-expand {
    font-size: 0;
  }
  .demo-table-expand label {
    width: 90px;
    color: #99a9bf;
  }
  .demo-table-expand .el-form-item {
    margin-right: 0;
    margin-bottom: 0;
    width: 50%;
  }
</style>
