import request from '@/utils/request'

// 查询神秘礼包中奖列表-分页
export function findSecretAddrPage(data) {
  return request({
    url: '/score/secretRuleCfg/findSecretAddrPage',
    method: 'post',
    server: 'server1',
    data
  })
}
// 设置发货状态
export function updateLogisticsStatus(data) {
  return request({
    url: '/score/secretRuleCfg/updateLogisticsStatus',
    method: 'post',
    server: 'server1',
    data
  })
}
// 查看所有备注
export function getSecretRemark(data) {
  return request({
    url: '/score/secretRuleCfg/getSecretRemark',
    method: 'post',
    server: 'server1',
    data
  })
}
