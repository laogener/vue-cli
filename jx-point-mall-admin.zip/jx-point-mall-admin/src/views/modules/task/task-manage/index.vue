<template>
  <div class="app-container">
    <el-row>
      <el-form ref="form" :inline="true" size="small" class="has-report-form-search">
        <el-form-item label="任务更新周期:">
          <el-select v-model="queryList.cycle" placeholder="请选择" style="width: 80px;">
            <el-option label="全部" value=""/>
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"/>
          </el-select>
        </el-form-item>
        <el-form-item label="任务状态:">
          <el-select v-model="queryList.taskStatus" placeholder="请选择" style="width: 80px;">
            <el-option label="全部" value=""/>
            <el-option
              v-for="item in options2"
              :key="item.value"
              :label="item.label"
              :value="item.value"/>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-input
            v-model="queryList.taskName"
            clearable
            placeholder="请输入任务名称"
            style="width: 150px;"
            clearable
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="query">搜索</el-button>
          <el-button type="primary" icon="el-icon-plus" @click="addOrModify()">新增</el-button>
        </el-form-item>
      </el-form>
    </el-row>

    <el-table v-loading="listLoading" :data="list" :height="tableHeight + 70" border fit highlight-current-row style="width: 100%;">
      <el-table-column type="index" width="50"/>
      <el-table-column prop="taskName" label="任务名称" show-overflow-tooltip align="center"/>
      <el-table-column prop="" label="任务更新周期" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.cycle == -1 ? '不更新' : scope.row.cycle == 0 ? '天' : scope.row.cycle == 1 ? '周' : '月' }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="" label="任务状态" align="center">
        <template slot-scope="scope">
          <span v-if="scope.row.taskStatus == 0" style="color: #67C23A">启用</span>
          <span v-else style="color: #F56C6C">禁用</span>
        </template>
      </el-table-column>
      <el-table-column prop="wapUrl" show-overflow-tooltip label="WAP任务链接" align="center"/>
      <el-table-column prop="pcUrl" show-overflow-tooltip label="PC任务链接" align="center"/>
      <el-table-column prop="appUrl" show-overflow-tooltip label="APP任务链接" align="center"/>
      <el-table-column prop="taskButtonName" show-overflow-tooltip label="任务按钮名称" align="center"/>
      <el-table-column prop=""  label="任务图标" align="center">
        <template slot-scope="scope">
          <img :src="scope.row.taskIcon" alt="" width="50">
        </template>
      </el-table-column>
      <el-table-column prop="reward" show-overflow-tooltip label="奖励" align="center"/>
      <el-table-column prop="" show-overflow-tooltip label="奖励类型" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.taskStatus == 0 ? '积分' : '' }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="taskInfo" show-overflow-tooltip label="任务信息" align="center"/>
      <el-table-column prop="" show-overflow-tooltip label="开始时间" align="center">
        <template slot-scope="scope">{{ scope.row.taskStartTime | timeFmtFilter }}</template>
      </el-table-column>
      <el-table-column prop="" show-overflow-tooltip label="结束时间" align="center">
        <template slot-scope="scope">{{ scope.row.taskEndTime | timeFmtFilter }}</template>
      </el-table-column>
      <el-table-column label="操作" align="center" width="300px" fixed="right">
        <template slot-scope="scope">
          <el-button type="primary" size="small" @click="detail(scope.row)">规则详情</el-button>
          <el-button type="primary" size="small" @click="addOrModify(scope.row)">修改任务</el-button>
          <el-button type="primary" size="small" @click="del(scope.row)">删除任务</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--      新增 修改 任务设置 弹窗-->
    <el-dialog :title="dialog.title" :visible.sync="dialog.dialogFormVisible" width="600px">
      <el-form :model="form" label-width="120px" style="max-height: 500px;overflow: auto">
        <el-form-item label="任务名称:">
          <el-input v-model="form.taskName" clearable/>
        </el-form-item>
        <el-form-item label="任务时间:">
          <el-date-picker
            v-model="timeRange"
            :picker-options="pickOptions"
            :default-time="['00:00:00', '23:59:59']"
            unlink-panels
            style="width:380px"
            clearable
            type="datetimerange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            align="right"
            value-format="yyyy-MM-dd HH:mm:ss"
          />
        </el-form-item>
        <el-form-item label="任务更新周期:">
          <el-select v-model="form.cycle" placeholder="请选择" style="width: 120px;">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"/>
          </el-select>
        </el-form-item>
        <el-form-item label="任务按钮名称:">
          <el-input v-model="form.taskButtonName" clearable/>
        </el-form-item>
        <el-form-item label="任务图标:">
          <el-upload
            :action="`${uploadHost}/score/signRuleCfg/uploadFile`"
            :show-file-list="false"
            :data="{siteCode: getSiteCode,fileDir:'sign'}"
            :on-success="handleSuccess"
            :on-error="onUploadFileError"
            class="avatar-uploader margin-top-15"
          >
            <img v-if="form.taskIcon" :src="form.taskIcon" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"/>
          </el-upload>
        </el-form-item>
        <el-form-item label="任务状态:">
          <el-select v-model="form.taskStatus" placeholder="请选择" style="width: 120px;">
            <el-option
              v-for="item in options2"
              :key="item.value"
              :label="item.label"
              :value="item.value"/>
          </el-select>
        </el-form-item>
        <el-form-item label="WAP任务链接:">
          <el-input v-model="form.wapUrl" clearable/>
        </el-form-item>
        <el-form-item label="PC任务链接:">
          <el-input v-model="form.pcUrl" clearable/>
        </el-form-item>
        <el-form-item label="APP任务链接:">
          <el-input v-model="form.appUrl" clearable/>
        </el-form-item>
        <el-form-item label="奖励:">
          <el-input v-model="form.reward" clearable/>
        </el-form-item>
        <el-form-item label="奖励类型:">
          <el-select v-model="form.rewardType" placeholder="请选择" style="width: 120px;">
            <el-option
              v-for="item in options3"
              :key="item.value"
              :label="item.label"
              :value="item.value"/>
          </el-select>
        </el-form-item>
        <el-form-item label="任务信息:">
          <el-input
            :rows="2"
            v-model="form.taskInfo"
            type="textarea"
            placeholder="请输入内容"/>
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialog.dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addOrModifySubmit">确 定</el-button>
      </div>
    </el-dialog>

    <el-dialog :visible.sync="dialogTableVisible" title="任务规则" width="70%">
      <el-table :data="list2">
        <el-table-column prop="" label="规则排序" align="center" width="80px">
          <template slot-scope="scope">
            <el-input v-model="scope.row.sort" :disabled="true"/>
          </template>
        </el-table-column>
        <el-table-column prop="ruleType" label="规则类型" align="center" width="100px">
          <template slot-scope="scope">
            <el-select v-model="scope.row.ruleType" placeholder="请选择">
              <el-option
                v-for="item in options5"
                :key="item.value"
                :label="item.label"
                :value="item.value"/>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column prop="" label="规则组" show-overflow-tooltip align="center" width="150px">
          <template slot-scope="scope">
            <el-input v-model="scope.row.ruleGroup" type="number" clearable/>
          </template>
        </el-table-column>
        <el-table-column prop="" label="基础属性code" align="center">
          <template slot-scope="scope">
            <el-select v-model="scope.row.basicCode" placeholder="请选择" @change="changeValue(scope.row)">
              <el-option
                v-for="item in basicList"
                :key="item.basicCode"
                :label="item.basicName"
                :value="item.basicCode"/>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="运算符" align="center" width="150px">
          <template slot-scope="scope">
            <el-select v-model="scope.row.operator" placeholder="请选择">
              <el-option
                v-for="item in options4"
                :key="item.value"
                :label="item.label"
                :value="item.value"/>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column prop="" label="基础属性值" align="left">
          <template slot-scope="scope">
            <el-input v-if="scope.row.basicType == 'number'" v-model="scope.row.basicValue" type="number" clearable/>
            <el-select v-else-if="scope.row.basicType == 'boolean'" v-model="scope.row.basicValue" placeholder="请选择" >
              <el-option
                v-for="item in options6"
                :key="item.value"
                :label="item.label"
                :value="item.value"/>
            </el-select>
            <el-date-picker v-else v-model="scope.row.basicValue" type="datetime" placeholder="选择日期时间" default-time="00:00:00"></el-date-picker>
          </template>
        </el-table-column>
        <el-table-column prop="" label="操作" align="center" width="120px">
          <template slot-scope="scope">
            <el-button type="danger" @click.prevent="remove(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div slot="footer" class="dialog-footer">
        <el-button @click="addRule" type="success">新增</el-button>
        <el-button @click="dialogTableVisible = false">取 消</el-button>
        <el-button type="primary" @click="ruleSubmit">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
    import {pickOptions} from '@/config/index'
    import {formatDate} from '@/utils'
    import {
        saveTaskCfg,
        updateTaskCfg,
        delTaskCfg,
        findTaskCfg,
        editRuleCfg,
        findRuleCfg,
        findBasic
    } from '@/api/modules/task'
    import {getSiteCode} from '@/utils/auth'
    import { HOST_LIST } from '@/config'

    export default {
        name: 'task-manage',
        filters: {
            timeFmtFilter(value) {
                return formatDate(new Date(value), 'yyyy-MM-dd hh:mm:ss')
            }
        },
        computed: {
            uploadHost() {
                return HOST_LIST[process.env.ENV_CONFIG]['server1']
            },
            getSiteCode() {
                return getSiteCode()
            }
        },
        data() {
            return {
                options: [// 任务更新周期
                    {value: -1, label: '不更新'},
                    {value: 0, label: '天'},
                    {value: 1, label: '周'},
                    {value: 2, label: '月'}
                ],
                options2: [// 任务状态
                    {value: 0, label: '启用'},
                    {value: 1, label: '禁用'}
                ],
                options3: [// 奖励类型
                    {value: 0, label: '积分'}
                ],
                options4: [// 运算符
                    {value: 'lt', label: '<'},
                    {value: 'le', label: '<='},
                    {value: 'eq', label: '='},
                    {value: 'ne', label: '!='},
                    {value: 'ge', label: '>='},
                    {value: 'gt', label: '>'}
                ],
                options5: [// 规则类型
                    {value: 0, label: '并且'},
                    {value: 1, label: '或者'}
                ],
                options6: [// 规则类型
                    {value: true, label: '是'},
                    {value: false, label: '否'}
                ],
                pickOptions,
                timeRange: [],
                queryList: {
                    taskName: '', // 任务名称
                    cycle: '', // 任务更新周期
                    taskStatus: '' // 任务状态
                },
                list: [],
                list2: [],
                basicList: [],
                listLoading: false,
                dialogTableVisible: false,
                dialogFormVisible: false,
                dialog: {
                    type: '',
                    title: '',
                    dialogFormVisible: false
                },
                form: {
                    taskName: '',
                    cycle: '',
                    taskStatus: '',
                    wapUrl: '',
                    pcUrl: '',
                    appUrl: '',
                    reward: '',
                    rewardType: 0,
                    taskInfo: '',
                    taskButtonName: '',
                    taskIcon: '',
                },
                form2: {
                    tId: '',
                    rules: []
                }
            }
        },
        created() {
            this.findBasic()
            this.query()
        },
        methods: {
            findBasic() {
                findBasic().then(({code, data}) => {
                    code == 200 && (this.basicList = data)
                }).catch(e => {
                     this.$message.error(e.msg)
                })
            },
            query() {
                this.listLoading = true
                findTaskCfg(this.queryList).then(({code, data}) => {
                    this.list = data
                }).catch(e => {
                     this.$message.error(e.msg)
                }).finally(() => (this.listLoading = false))
            },
            // 规则详情
            detail(row) {
                this.form2.tId = row.id
                findRuleCfg({tId: row.id}).then(({code, data}) => {
                    if (code == 200) {
                        data.forEach( item => {
                            this.basicList.map( item2 => {
                                if(item.basicCode == item2.basicCode){
                                   item.basicType = item2.basicType
                                }
                            })
                        })
                        this.list2 = data
                        this.dialogTableVisible = true
                    }
                }).catch(e => {
                     this.$message.error(e.msg)
                })
            },
            // 新增 修改 任务设置 按钮
            addOrModifySubmit() {
                if (!this.form.taskName) {
                    this.$message.info('请输入任务名称')
                    return false
                }
                if (this.timeRange.length == 0) {
                    this.$message.info('请选择任务时间')
                    return false
                }
                if (!this.form.taskButtonName) {
                    this.$message.info('请输入任务按钮名称')
                    return false
                }
                if (!this.form.taskIcon) {
                    this.$message.info('请上传任务图标')
                    return false
                }
                if (!this.form.wapUrl) {
                    this.$message.info('WAP任务链接')
                    return false
                }
                if (!this.form.pcUrl) {
                    this.$message.info('PC任务链接')
                    return false
                }
                if (!this.form.appUrl) {
                    this.$message.info('APP任务链接')
                    return false
                }

                if (!this.form.reward) {
                    this.$message.info('请输入奖励')
                    return false
                }
                if (!this.form.taskInfo) {
                    this.$message.info('任务信息')
                    return false
                }

                let api = null
                this.form.taskStartTime = this.timeRange ? this.timeRange[0] : ''
                this.form.taskEndTime = this.timeRange ? this.timeRange[1] : ''
                const query = this.form
                if (this.dialog.type == 'modify') {
                    api = updateTaskCfg
                } else {
                    api = saveTaskCfg
                }
                api(query).then(({code}) => {
                    code == 200 && this.$message.success(this.dialog.title + '成功') && this.query()
                }).catch(e => {
                    this.$message.error(e.msg)
                })
                this.dialog.dialogFormVisible = false
            },
            // 新增 修改 任务设置 弹窗
            addOrModify(row) {
                if (row) {
                    this.dialog.type = 'modify'
                    this.dialog.title = '修改任务'
                    Object.assign(this.form,row)
                    this.timeRange[0] = formatDate(new Date(row.taskStartTime), 'yyyy-MM-dd hh:mm:ss')
                    this.timeRange[1] = formatDate(new Date(row.taskEndTime), 'yyyy-MM-dd hh:mm:ss')
                } else {
                    this.resetFrom()
                    this.dialog.type = 'add'
                    this.dialog.title = '新增任务'
                }
                this.dialog.dialogFormVisible = true
            },
            resetFrom() {
                delete this.form.id
                this.form.taskName = ''
                this.form.cycle = -1
                this.form.taskStatus = 0
                this.form.wapUrl = ''
                this.form.pcUrl = ''
                this.form.appUrl = ''
                this.form.reward = ''
                this.form.rewardType = 0
                this.form.taskInfo = ''
                this.form.taskButtonName = ''
                this.form.taskIcon = ''
                this.timeRange = []
            },

            ruleSubmit() {
                const canSubmit = this.list2.every(item => {

                    if (!item.ruleGroup) {
                        this.$message.info('请输入规则组')
                        return false
                    }
                    return true
                })
                this.form2.rules = this.list2;
                canSubmit && editRuleCfg(this.form2).then(({code}) => {
                    code == 200 && this.$message.success('任务规则编辑成功')
                }).catch(e => {
                    this.$message.error('任务规则编辑失败')
                })
            },
            del(row) {
                this.$confirm(
                    `<div>
        <div style="display: flex"><span style="width: 160px;text-align: right">任务设置ID：</span>${row.id}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">任务名称：</span>${row.taskName}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">奖励：</span>${row.reward}</div>
      </div>`
                    , '确认删除该任务？', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning',
                        dangerouslyUseHTMLString: true,
                        center: true
                    }).then(() => {
                    delTaskCfg({id: row.id}).then(({code}) => {
                        code == 200 && this.$message.success('删除成功') && this.query()
                    }).catch(e => {
                        this.$message.error('删除失败')
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    })
                })
            },
            remove(row) {
                const index = this.list2.indexOf(row)
                if (index !== -1) {
                    this.list2.splice(index, 1)
                }
            },
            addRule() {
                this.list2.push({
                    sort: this.list2.length + 1,
                    ruleType: 0,
                    ruleGroup: '',
                    basicCode: this.basicList[0].basicCode,
                    basicType: this.basicList[0].basicType,
                    operator: 'lt',
                    basicValue: ''
                })
            },
            changeValue(row){
                this.basicList.map(item => {
                    item.basicCode == row.basicCode && ( row.basicType=item.basicType)
                })
            },
            // 上传图片
            handleSuccess(res, file, fileList) {
                this.form.taskIcon = res.data || ''
            },
            onUploadFileError(err, file, fileList) {
                this.$message.error(err.msg || '上传图片失败')
            },
        }
    }
</script>

<style scoped>

</style>
