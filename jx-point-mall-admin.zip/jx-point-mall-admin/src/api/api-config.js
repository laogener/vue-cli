const config = {
  newsUploadUrl: ''
}
export default config

