<template>
  <div class="navbar">
    <hamburger
      :toggle-click="toggleSideBar"
      :is-active="sidebar.opened"
      class="hamburger-container"
    />

    <breadcrumb class="breadcrumb-container" />

    <div class="right-menu">
      <!--换肤按钮-->
      <div class="skin right-menu-item">
        <el-dropdown trigger="click" @command="onSkinSwitchClick">
          <span class="el-dropdown-link" style="cursor: pointer;">
            换肤
            <i class="el-icon-arrow-down el-icon--right"/>
          </span>
          <el-dropdown-menu slot="dropdown" class="skin-drop-down-list">
            <el-dropdown-item command="theme-dark">暗黑</el-dropdown-item>
            <el-dropdown-item command="theme-default">默认</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
      <!-- 登陆头像 -->
      <el-dropdown class="avatar-container right-menu-item" trigger="click">
        <div class="user right-menu-item" style="cursor: pointer;">
          <span class="svg-container">
            <svg-icon icon-class="userIcon" class="svg-icon icon" />
          </span>
          <span class="icon-bottom">
            <i class="el-icon-caret-bottom"/>
          </span>
        </div>
        <el-dropdown-menu slot="dropdown">
          <router-link to="/task/task-manage">
            <el-dropdown-item>{{ $t('navbar.dashboard') }}</el-dropdown-item>
          </router-link>
          <el-dropdown-item divided>
            <span style="display:block;" @click="logout">{{ $t('navbar.logOut') }}</span>
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>

    </div>
  </div>
</template>

<script>

import { mapGetters } from 'vuex'
import Breadcrumb from '@/components/Breadcrumb'
import Hamburger from '@/components/Hamburger'
import ErrorLog from '@/components/ErrorLog'
import Screenfull from '@/components/Screenfull'
import SizeSelect from '@/components/SizeSelect'
import LangSelect from '@/components/LangSelect'
import ThemePicker from '@/components/ThemePicker'
import { global } from '@/utils/theme'

export default {
  components: {
    Breadcrumb,
    Hamburger,
    ErrorLog,
    Screenfull,
    SizeSelect,
    LangSelect,
    ThemePicker
  },
  computed: {
    ...mapGetters(['sidebar', 'name', 'avatar', 'device', 'unreadMessage']),
    totalMsg() {
      const rechargeCount = Number(this.unreadMessage.rechargeNumber)
      const withdrawCount = Number(this.unreadMessage.withdrawNumber)
      const feedbackCount = Number(this.unreadMessage.suggestionNumber)
      this.msgType =
                    rechargeCount > 0 || withdrawCount > 0 ? 'danger' : 'warning'
      return rechargeCount + feedbackCount + withdrawCount
    }
  },
  data() {
    return {
      webSocketMsg: '',
      totalNumberMsg: '0',
      dialogFormVisible: false,
      form: {
        oldUserPwd: '',
        newpassword1: '',
        newpassword2: ''
      },
      msgType: 'warning',
      formLabelWidth: '120px',
      pwdType: 'password',
      loginData: [{ loginDate: '暂无' }],

      query: {
        pageNumber: 1,
        pageSize: 50,
        status: 1// 0-成功，1-进行中，2-失败，3-删除，这个URL中的status参数必须是1
      },
      list: [],
      auth: {
        show: false,
        code: '',
        imgSrc: ''
      }

    }
  },
  watch: {
    dialogFormVisible: 'clearForm'
  },
  created() {
  },
  methods: {

    onSkinSwitchClick(command) {
      global.changeTheme(command)
      global.toggleClass(document.body, command)
    },

    toggleSideBar() {
      this.$store.dispatch('toggleSideBar')
    },

    showPwd(e) {
      this.pwdType === 'password'
        ? (this.pwdType = '')
        : (this.pwdType = 'password')
      this.pwdType === ''
        ? e.target.setAttribute('style', 'color: #409EFF')
        : e.target.setAttribute('style', 'color: #c0c4cc')
    },
    logout() {
      this.$store.dispatch('LogOut').then(() => {
        location.reload() // In order to re-instantiate the vue-router object to avoid bugs
      })
    },
    clearForm() {
      if (!this.dialogFormVisible) {
        this.form = {}
      }
    }

  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .navbar {
    height: 50px;
    line-height: 50px;
    border-radius: 0 !important;
    .hamburger-container {
      line-height: 58px;
      height: 50px;
      float: left;
      padding: 0 10px;
    }
    .breadcrumb-container {
      float: left;
    }
    .errLog-container {
      display: inline-block;
      vertical-align: top;
    }
    .right-menu {
      float: right;
      height: 100%;
      &:focus {
        outline: none;
      }
      .right-menu-item {
        display: inline-block;
        /*margin: 0 8px;*/
        padding: 0 10px;
      }
      .latest-login {
        .svg-container {
          padding: 7px;
          width: 24px;
          height: 24px;
          border-radius: 50%;
          margin-right: 5px;
          .icon.svg-icon {
            color: #fff;
          }
        }
        .text {
          font-size: 12px;
          color: #818181;
        }
      }
      .message {
        .svg-icon {
          position: relative;
          top: 5px;
          width: 20px;
          height: 20px;
        }
      }
      .user {
        .svg-container {
          padding: 5px;
          border-radius: 50%;
        }
        .icon-bottom {
        }
      }
    }
  }

  .unreadMessages {
    vertical-align: 8px;
  }

  .msg-badge {
    position: static;
  }

  .messages-icon {
    font-size: 26px;
    cursor: pointer;
  }

  .messages-icon-insider {
    font-size: 12px;
  }

  .skin-drop-down-list {
    top: 35px !important;
  }

  .message-drop-down-list {
    top: 35px !important;
    a {
      li {
        padding: 0 10px !important;
        .numbers {
          display: inline-block;
          text-align: right;
          width: 50px;
          margin-left: 2px;
        }
      }
    }
  }
</style>
