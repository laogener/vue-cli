<template>
  <div class="app-container">
    <div class="filter-container">
      <el-input v-model="listQuery.account" class="small-width filter-item" placeholder="账号" @keyup.enter.native="handleFilter"/>
      <el-select v-model="listQuery.lottery" placeholder="类型">
        <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value"/>
      </el-select>
      <el-date-picker v-model="listQuery.dateTimer" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期"/>
      <el-button v-waves class="filter-item" type="primary" icon="el-icon-search" @click="handleFilter">查询</el-button>
      <el-button v-waves class="filter-item" type="primary" icon="el-icon-search">导出</el-button>
    </div>
    <el-table v-loading="listLoading" :data="list" element-loading-text="loading" border fit highlight-current-row style="width: 100%">
      <el-table-column type="index" width="50"/>
      <el-table-column align="center" label="账号">
        <template slot-scope="scope">
          <span>{{ scope.row.payAccount }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="交易金额">
        <template slot-scope="scope">
          <span>{{ scope.row.siteCode }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="交易后金额" show-overflow-tooltip>
        <template slot-scope="scope">
          <span>{{ scope.row.accountMode }}</span>
        </template>
      </el-table-column>
      <el-table-column align="left" label="类型" show-overflow-tooltip>
        <template slot-scope="scope">
          <span>{{ scope.row.accountStatus }}</span>
        </template>
      </el-table-column>
      <el-table-column align="left" label="订单号" show-overflow-tooltip>
        <template slot-scope="scope">
          <span>{{ scope.row.accountStatus }}</span>
        </template>
      </el-table-column>
      <el-table-column align="left" label="期数" show-overflow-tooltip>
        <template slot-scope="scope">
          <span>{{ scope.row.accountStatus }}</span>
        </template>
      </el-table-column>
      <el-table-column align="left" label="玩法" show-overflow-tooltip>
        <template slot-scope="scope">
          <span>{{ scope.row.accountStatus }}</span>
        </template>
      </el-table-column>
      <el-table-column align="left" label="投注号码" show-overflow-tooltip>
        <template slot-scope="scope">
          <span>{{ scope.row.accountStatus }}</span>
        </template>
      </el-table-column>
      <el-table-column align="left" label="时间" show-overflow-tooltip>
        <template slot-scope="scope">
          <span>{{ scope.row.accountStatus }}</span>
        </template>
      </el-table-column>
      <el-table-column align="left" label="说明" show-overflow-tooltip>
        <template slot-scope="scope">
          <span>{{ scope.row.accountStatus }}</span>
        </template>
      </el-table-column>
    </el-table>

    <div class="pagination-container">
      <el-pagination
        :current-page="pageNum"
        :page-sizes="[10,20,30,50]"
        :page-size="pageSize"
        :total="total"
        background
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"/>
    </div>

    <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible">
      <el-form ref="dataForm" :rules="rules" :model="form" label-position="right" label-width="120px">
        <el-row>
          <el-col :span="10">
            <el-form-item label="用户账号" prop="pay_account">
              <el-input v-model="form.payAccount"/>
            </el-form-item>
          </el-col>
          <el-col :span="14">
            <el-form-item label="所属站点" prop="site_code">
              <el-input v-model="form.siteCode"/>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="单日最大笔数" prop="day_max_count">
              <el-input v-model="form.dayMaxCount"/>
            </el-form-item>
          </el-col>
          <el-col :span="14">
            <el-form-item label="账号类型" prop="account_mode">
              <el-radio-group v-model="form.accountMode">
                <el-radio :label="0">支付宝</el-radio>
                <el-radio :label="1">微信</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="10">
            <el-form-item label="单日最大金额" prop="day_max_amount">
              <el-input v-model="form.dayMaxAmount"/>
            </el-form-item>
          </el-col>
          <el-col :span="14">
            <el-form-item label="账号最大金额" prop="max_amount">
              <el-input v-model="form.maxAmount"/>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="10">
            <el-form-item label="单日警告笔数" prop="day_warning_count">
              <el-input v-model="form.dayWarningCount"/>
            </el-form-item>
          </el-col>
          <el-col :span="14">
            <el-form-item label="单日警告金额" prop="day_warning_amount">
              <el-input v-model="form.dayWarningAmount"/>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="10">
            <el-form-item label="账号警告金额" prop="warning_amount">
              <el-input v-model="form.warningAmount"/>
            </el-form-item>
          </el-col>
          <el-col :span="14">
            <el-form-item label="账号初始余额" prop="account_init_amount">
              <el-input v-model="form.accountInitAmount"/>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="10">
            <el-form-item label="账号活动金额" prop="account_active_amount">
              <el-input v-model="form.accountActiveAmount"/>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">{{ $t('table.cancel') }}</el-button>
        <el-button v-if="dialogStatus==='create'" type="primary" @click="createData">{{ $t('table.confirm') }}</el-button>
        <el-button v-else type="primary" @click="updateData">{{ $t('table.confirm') }}</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import waves from '@/directive/waves'
import { list, add, update, del } from '@/api/business/pay/account-manage'
import tableMixin from '@/mixin/table'

export default {
  name: 'BalanceLog',
  directives: {
    waves
  },
  mixins: [tableMixin],
  data() {
    return {
      rules: {},
      config: {
        add: add,
        del: del,
        update: update,
        list: list,
        form: {
          payAccount: '',
          siteCode: '',
          accountMode: 0,
          dayMaxCount: 0,
          dayMaxAmount: 0.00,
          maxAmount: 0.00,
          dayWarningCount: 0,
          dayWarningAmount: 0.00,
          warningAmount: 0.00,
          accountInitAmount: 0.00,
          accountActiveAmount: 0.00
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
  .demo-table-expand {
    font-size: 0;
  }
  .demo-table-expand label {
    width: 90px;
    color: #99a9bf;
  }
  .demo-table-expand .el-form-item {
    margin-right: 0;
    margin-bottom: 0;
    width: 50%;
  }
</style>
