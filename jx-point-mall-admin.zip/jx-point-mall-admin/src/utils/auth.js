import Cookies from 'js-cookie'

let ID;
(function() {
  const idKey = '___USER__ID__'
  ID = sessionStorage.getItem(idKey)
  if (!ID) {
    ID = Date.now()
    sessionStorage.setItem(idKey, ID)
  }
})()

const TokenKey = 'Admin-Token' + ID
const SiteCodeKey = 'Admin-Site-Code' + ID
const AccountKey = 'Admin-Account' + ID
const MenuListKey = 'Admin-Menu-List' + ID
const AdminThemeKey = 'Admin-Theme-Key' + ID

export function getTheme() {
  return Cookies.get(AdminThemeKey)
}

export function setTheme(themeName) {
  return Cookies.set(AdminThemeKey, themeName)
}

export function removeTheme() {
  return Cookies.remove(AdminThemeKey)
}

export function getToken() {
  return Cookies.get(TokenKey) || ''
}

export function setToken(token) {
  return Cookies.set(TokenKey, token)
}
export function removeToken() {
  return Cookies.remove(TokenKey)
}
export function getSiteCode() {
  return Cookies.get(SiteCodeKey) || ''
}

export function setSiteCode(siteCode) {
  return Cookies.set(SiteCodeKey, siteCode)
}
export function removeSiteCode() {
  return Cookies.remove(SiteCodeKey)
}
export function getAccount() {
  return Cookies.get(AccountKey) || ''
}

export function setAccount(account) {
  return Cookies.set(AccountKey, account)
}
export function removeAccount() {
  return Cookies.remove(AccountKey)
}

export function getMenuList() {
  return Cookies.get(MenuListKey) || ''
}

export function setMenuList(menuList) {
  return Cookies.set(MenuListKey, menuList)
}
export function removeMenuList() {
  return Cookies.remove(MenuListKey)
}

