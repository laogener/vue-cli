<template>
  <div>首页内容配置</div>
</template>

<script>
export default {
  name: 'Index'
}
</script>

<style scoped>

</style>
