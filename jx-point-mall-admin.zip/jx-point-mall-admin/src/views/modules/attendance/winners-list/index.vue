<template>
  <div class="app-container">
    <el-row>
      <el-form ref="form" :inline="true" size="small" class="has-report-form-search">
        <el-form-item>
          <el-input v-model="queryList.remark" placeholder="关键字：奖品名称、签到天数、手机号、备注" style="width: 300px;" clearable/>
        </el-form-item>
        <el-form-item label="发货状态:">
          <el-select v-model="queryList.logisticsStatus" placeholder="请选择" style="width: 100px;">
            <el-option label="全部" value=""/>
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"/>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="query('btn')">搜索</el-button>
        </el-form-item>
      </el-form>
    </el-row>
    <el-table v-loading="listLoading" :data="list" :height="tableHeight + 70" border fit highlight-current-row
              style="width: 100%;">
      <el-table-column type="index" width="50"/>
      <el-table-column prop="giftName" label="奖品名称" show-overflow-tooltip align="center"/>
      <el-table-column prop="signDay" label="签到天数" show-overflow-tooltip align="center"  width="90"/>
      <el-table-column prop="" label="中奖对象" show-overflow-tooltip align="center"  width="90">
        <template slot-scope="scope">{{ scope.row.type == 1 ? '全部会员' : '指定会员' }}</template>
      </el-table-column>
      <el-table-column prop="createBy" label="会员账号" show-overflow-tooltip align="center"  width="90"/>
      <el-table-column prop="userPhone" label="手机号" show-overflow-tooltip align="center"  width="120"/>
      <el-table-column prop="logisticsStatus" label="物流状态" show-overflow-tooltip align="center" width="90"/>
      <el-table-column prop="" label="收货地址" align="left">
        <template slot-scope="scope">
          <div>收货人：{{ scope.row.userName }}，手机号：{{ scope.row.userPhone }}；地址：{{ scope.row.province }}{{ scope.row.city
            }}{{ scope.row.region }}{{ scope.row.address }}
          </div>
        </template>
      </el-table-column>

      <el-table-column prop="remark" label="备注" show-overflow-tooltip align="center"/>
      <el-table-column label="操作" align="center" width="250px">
        <template slot-scope="scope">
          <el-button type="primary" size="small" @click="setStatus(scope.row)">设置发货状态</el-button>
          <el-button type="primary" size="small" @click="lookAllMark(scope.row)">所有备注记录</el-button>
        </template>
      </el-table-column>
    </el-table>

    <Pagination
      v-show="total>0"
      :page-sizes="[20,50,100,200,500]"
      :total="total"
      :page.sync="queryList.pageNum"
      :limit.sync="queryList.pageSize"
      @pagination="query"
    />
    <!--      设置发货状态-->
    <el-dialog :title="dialog.title" :visible.sync="dialog.dialogFormVisible" width="750px">
      <el-form :model="form" label-width="150px">

        <el-form-item label="发货状态:">
          <el-select v-model="form.logisticsStatus" placeholder="请选择" style="width: 120px;">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"/>
          </el-select>
        </el-form-item>
        <el-form-item label="备注:">
          <el-input :rows="2" v-model="form.remark" type="textarea" placeholder="请输入内容"/>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialog.dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="setStatusSubmit">确 定</el-button>
      </div>
    </el-dialog>

    <el-dialog :visible.sync="dialogTableVisible" title="收货地址">
      <el-table :data="list2">
        <el-table-column type="index" width="50"/>
        <el-table-column show-overflow-tooltip align="center" property="giftNo" label="奖品编号"/>
        <el-table-column show-overflow-tooltip align="center" property="createTime" label="时间"/>
        <el-table-column show-overflow-tooltip align="center" property="logisticsStatus" label="发货状态"/>
        <el-table-column show-overflow-tooltip align="center" property="address" label="地址"/>
        <el-table-column show-overflow-tooltip align="center" property="remark" label="备注"/>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
    import {findSecretAddrPage, updateLogisticsStatus, getSecretRemark} from '@/api/modules/attendance/winners-list'
    import Pagination from '@/components/Pagination'
    import {getAccount} from '@/utils/auth'

    export default {
        name: 'WinnersList',
        components: {Pagination},
        data() {
            return {
                options: [// 签到天数
                    {value: '待发货', label: '待发货'},
                    {value: '已发货', label: '已发货'},
                    {value: '不发货', label: '不发货'}
                ],
                queryList: {
                    remark: '',
                    logisticsStatus: '',
                    pageSize: 20,
                    pageNum: 1
                },

                list: [],
                list2: [],
                listLoading: false,
                dialogTableVisible: false,
                total: 0,
                dialog: {
                    type: '',
                    title: '',
                    dialogFormVisible: false
                },

                form: {
                    remark: '',
                    giftNo: '',
                    addrNo: '',
                    logisticsStatus: ''
                }
            }
        },
        created() {
            this.query()
        },
        methods: {
            query(val) {
                if (val == 'btn') {
                    this.queryList.pageNum == 1
                }
                this.listLoading = true
                findSecretAddrPage(this.queryList).then(({code, data}) => {
                    this.list = data.list
                    this.total = data.total
                }).catch(e => {
                     this.$message.error(e.msg)
                }).finally(() => (this.listLoading = false))
            },
            // 设置发货状态 按钮
            setStatusSubmit() {

                if (!this.form.remark) {
                    this.$message.info('请输入备注')
                    return false
                }

                const query = this.form

                updateLogisticsStatus(query).then(({code}) => {
                    code == 200 && this.$message.success(this.dialog.title + '成功') && this.query()
                }).catch(e => {
                    this.$message.error(e.msg)
                })
                this.dialog.dialogFormVisible = false
            },
            // 设置发货状态
            setStatus(row) {
                this.resetFrom()
                this.dialog.title = '设置发货状态'
                Object.assign(this.form,row)
                this.dialog.dialogFormVisible = true
            },
            resetFrom() {
                delete this.form.id
                this.form.remark = ''
                this.form.giftNo = ''
                this.form.addrNo = ''
                this.form.logisticsStatus = ''
            },
            // 查看所有备注记录
            lookAllMark(row) {
                getSecretRemark({giftNo: row.giftNo, addrNo: row.addrNo}).then(({code, data}) => {
                    this.list2 = data
                    this.dialogTableVisible = true
                }).catch(e => {
                     this.$message.error(e.msg)
                })
            }
        }
    }
</script>

<style scoped>
  .el-table .cell {
    white-space: pre-line;
  }
</style>
