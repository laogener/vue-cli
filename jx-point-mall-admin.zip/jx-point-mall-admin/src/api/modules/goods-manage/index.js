import request from '@/utils/request'

// 添加商品
export function saveProduct(data) {
  return request({
    url: '/admin/product/saveProduct',
    method: 'post',
    server: 'server2',
    data
  })
}
// 修改商品
export function updateProduct(data) {
  return request({
    url: '/admin/product/updateProduct',
    method: 'post',
    server: 'server2',
    data
  })
}
// 删除商品
export function delProduct(data) {
  return request({
    url: '/admin/product/delProduct',
    method: 'post',
    server: 'server2',
    data
  })
}
// 查询商品-分页
export function listProductPage(data) {
  return request({
    url: '/admin/product/listProductPage',
    method: 'post',
    server: 'server2',
    data
  })
}
// 查询商品分类
export function listProductType(data) {
  return request({
    url: '/web/type/listProductType',
    method: 'post',
    server: 'server2',
    data
  })
}

