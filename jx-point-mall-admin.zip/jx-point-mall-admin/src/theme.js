import { global } from '@/utils/theme'
import { getTheme } from '@/utils/auth'

if (getTheme()) {
  global.changeTheme(getTheme())
  global.toggleClass(document.body, getTheme())
} else {
  global.changeTheme('theme-default')
  global.toggleClass(document.body, 'theme-default')
}
global.setModalWith()
