import request from '@/utils/request'

// 新增活动规则
export function saveActivityCfg(data) {
  return request({
    url: '/score/activityCfg/saveActivityCfg',
    method: 'post',
    server: 'server1',
    data
  })
}
// 删除活动规则
export function removeActivityCfg(data) {
  return request({
    url: '/score/activityCfg/removeActivityCfg',
    method: 'post',
    server: 'server1',
    data
  })
}
// 修改活动规则
export function updateActivityCfg(data) {
  return request({
    url: '/score/activityCfg/updateActivityCfg',
    method: 'post',
    server: 'server1',
    data
  })
}
// 查询活动规则-分页
export function findActivityCfgPage(data) {
  return request({
    url: '/score/activityCfg/findActivityCfgPage',
    method: 'post',
    server: 'server1',
    data
  })
}
