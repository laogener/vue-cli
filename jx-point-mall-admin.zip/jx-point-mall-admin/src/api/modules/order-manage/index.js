import request from '@/utils/request'

// 查询订单-分页
export function listUserOrderPage(data) {
  return request({
    url: '/admin/order/listUserOrderPage',
    method: 'post',
    server: 'server2',
    data
  })
}

// 修改订单
export function updateUserOrder(data) {
  return request({
    url: '/admin/order/updateUserOrder',
    method: 'post',
    server: 'server2',
    data
  })
}
// 新增物流
export function save(data) {
  return request({
    url: '/admin/logistics/save',
    method: 'post',
    server: 'server2',
    data
  })
}
// 查询物流
export function listLogistics(data) {
  return request({
    url: '/admin/logistics/listLogistics',
    method: 'post',
    server: 'server2',
    data
  })
}
// 查询物流
export function listProductType(data) {
  return request({
    url: '/admin/type/listProductType',
    method: 'post',
    server: 'server2',
    data
  })
}
