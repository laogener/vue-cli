<template>
  <div class="app-container">
    <el-table v-loading="listLoading" :data="list" element-loading-text="loading" border fit highlight-current-row style="width: 100%">
      <el-table-column type="index" width="50"/>
      <el-table-column align="center" label="编号">
        <template slot-scope="scope">
          <span>{{ scope.row.payAccount }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="登录地区">
        <template slot-scope="scope">
          <span>{{ scope.row.siteCode }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="登录IP" show-overflow-tooltip>
        <template slot-scope="scope">
          <span>{{ scope.row.accountMode }}</span>
        </template>
      </el-table-column>
      <el-table-column align="left" label="登录时间" show-overflow-tooltip>
        <template slot-scope="scope">
          <span>{{ scope.row.accountStatus }}</span>
        </template>
      </el-table-column>
    </el-table>

    <div class="pagination-container">
      <el-pagination
        :current-page="pageNum"
        :page-sizes="[10,20,30,50]"
        :page-size="pageSize"
        :total="total"
        background
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"/>
    </div>
  </div>
</template>

<script>
import waves from '@/directive/waves'
import { list, add, update, del } from '@/api/business/pay/account-manage'
import tableMixin from '@/mixin/table'

export default {
  name: 'SettingLoginLog',
  directives: {
    waves
  },
  mixins: [tableMixin],
  data() {
    return {
      rules: {},
      config: {
        add: add,
        del: del,
        update: update,
        list: list,
        form: {
          payAccount: '',
          siteCode: '',
          accountMode: 0,
          dayMaxCount: 0,
          dayMaxAmount: 0.00,
          maxAmount: 0.00,
          dayWarningCount: 0,
          dayWarningAmount: 0.00,
          warningAmount: 0.00,
          accountInitAmount: 0.00,
          accountActiveAmount: 0.00
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
  .demo-table-expand {
    font-size: 0;
  }
  .demo-table-expand label {
    width: 90px;
    color: #99a9bf;
  }
  .demo-table-expand .el-form-item {
    margin-right: 0;
    margin-bottom: 0;
    width: 50%;
  }
</style>
