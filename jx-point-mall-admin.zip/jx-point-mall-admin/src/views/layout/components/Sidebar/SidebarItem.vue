<template>
  <div v-if="!item.hidden&&item.children" class="menu-wrapper">
    <template
      v-if="hasOneShowingChild(item.children,item) && (!onlyOneChild.children||onlyOneChild.noShowingChildren)&&!item.alwaysShow"
    >
      <app-link :to="resolvePath(onlyOneChild.path)">
        <el-menu-item
          :index="resolvePath(onlyOneChild.path)"
          :class="{'submenu-title-noDropdown':!isNest}"
          class="no-icon mmm"
        >
          <item
            v-if="onlyOneChild.meta"
            :icon="getSubMenuIcon(onlyOneChild.meta||item.meta)"
            :title="generateTitle(onlyOneChild.meta.title)"
          />
        </el-menu-item>
      </app-link>
    </template>

    <el-submenu v-else ref="submenu" :index="resolvePath(item.path)">
      <template slot="title">
        <item
          v-if="item.meta"
          :icon="getSubMenuIcon(item.meta)"
          :title="generateTitle(item.meta.title)"
          class="jjj"
        />
      </template>

      <template v-for="child in item.children" v-if="!child.hidden">
        <sidebar-item
          v-if="child.children&&child.children.length>0"
          :is-nest="true"
          :item="child"
          :key="child.path"
          :base-path="resolvePath(child.path)"
          class="nest-menu qqq"
        />

        <app-link v-else :to="resolvePath(child.path)" :key="child.name">
          <el-menu-item :index="resolvePath(child.path)">
            <item v-if="child.meta" :title="generateTitle(child.meta.title)" class="eee" />
          </el-menu-item>
        </app-link>
      </template>
    </el-submenu>
  </div>
</template>

<script>
import path from 'path'
import { generateTitle } from '@/utils/i18n'
import { isExternal } from '@/utils'
import Item from './Item'
import AppLink from './Link'
import FixiOSBug from './FixiOSBug'

export default {
  name: 'SidebarItem',
  components: { Item, AppLink },
  mixins: [FixiOSBug],
  props: {
    // route object
    item: {
      type: Object,
      required: true
    },
    isNest: {
      type: Boolean,
      default: false
    },
    basePath: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      onlyOneChild: null
    }
  },
  created() {
    // console.log(111)
    // console.log(this.item)
  },
  methods: {
    hasOneShowingChild(children, parent) {
      const showingChildren = children.filter(item => {
        if (item.hidden) {
          return false
        } else {
          // Temp set(will be used if only has one showing child)
          this.onlyOneChild = item
          return true
        }
      })

      // When there is only one child router, the child router is displayed by default
      if (showingChildren.length === 1) {
        return true
      }

      // Show parent if there are no child router to display
      if (showingChildren.length === 0) {
        this.onlyOneChild = { ...parent, path: '', noShowingChildren: true }
        return true
      }

      return false
    },
    resolvePath(routePath) {
      if (this.isExternalLink(routePath)) {
        return routePath
      }
      return path.resolve(this.basePath, routePath)
    },
    isExternalLink(routePath) {
      return isExternal(routePath)
    },
    getSubMenuIcon(menuItem) {
      switch (menuItem.title) {
        case 'dashboard':
          return 'controlPanel'
        case '数据实时指标':
          return 'chart'
        case '返水管理':
          return 'drag'
        case '报表管理':
          return 'list'
        case '会员管理':
          return 'member'
        case '财务管理':
          return 'financial'
        case '注单管理':
          return 'bet'
        case '日志管理':
          return 'logManage'
        case '代理管理':
          return 'agent'
        case '消息管理':
          return 'messageManage'
        case '活动管理':
          return 'activity'
        case '网站管理':
          return 'webSite'
        case '系统设置':
          return 'systemSetting'
        case '新游戏中心':
          return 'new-game'
        case '游戏基础设置':
          return 'gameBaseSetting'
        case '来源规则配置':
          return 'sourceRuleConfig'
        default:
          return 'icon'
      }
    },
    generateTitle
  }
}
</script>
