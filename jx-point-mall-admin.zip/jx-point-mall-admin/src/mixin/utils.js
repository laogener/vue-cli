import Vue from 'vue'

Vue.mixin({
  computed: {
    tableHeight() {
      return document.documentElement.clientHeight - 310
    }
  }
})
