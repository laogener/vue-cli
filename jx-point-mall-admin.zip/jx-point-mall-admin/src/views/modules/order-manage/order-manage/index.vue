<template>
  <div class="app-container">
    <el-row>
      <el-form ref="form" :inline="true" size="small" class="has-report-form-search">
        <el-form-item>
          <el-input v-model="queryList.productName" placeholder="收货人信息、用户ID、商品名称、订单ID" style="width: 250px;" clearable/>
        </el-form-item>
        <el-form-item label="订单状态:">
          <el-select v-model="queryList.status" placeholder="请选择" style="width: 100px;">
            <el-option label="全部" value=""/>
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"/>

          </el-select>
        </el-form-item>
        <el-form-item label="商品分类:">
          <el-select v-model="queryList.typeName" placeholder="请选择" style="width: 200px;">
            <el-option label="全部" value=""/>
            <el-option
              v-for="item in listProduct"
              :key="item.typeNo"
              :label="item.typeName"
              :value="item.typeName"/>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-date-picker
            v-model="timeRange"
            :picker-options="pickOptions"
            :default-time="['00:00:00', '23:59:59']"
            unlink-panels
            style="width:380px"
            clearable
            type="datetimerange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            align="right"
            value-format="yyyy-MM-dd HH:mm:ss"
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="query('btn')">搜索</el-button>
          <el-button type="primary" @click="addOrModify('batch','batch')">批量修改</el-button>
        </el-form-item>
      </el-form>
    </el-row>
    <el-table v-loading="listLoading" :data="list" :height="tableHeight + 70" border fit highlight-current-row
              style="width: 100%;" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column prop="userAccount" label="用户" show-overflow-tooltip align="center"/>
      <el-table-column prop="productName" label="商品名称" show-overflow-tooltip align="center" width="200"/>
      <el-table-column prop="price" label="单价" show-overflow-tooltip align="center"/>
      <el-table-column prop="productNum" label="商品数量" show-overflow-tooltip align="center"/>
      <el-table-column prop="typeName" label="商品类型" show-overflow-tooltip align="center"/>
      <el-table-column prop="model" label="商品型号" show-overflow-tooltip align="center"/>
      <el-table-column prop="logisticsStatus" label="物流状态" width="150px" show-overflow-tooltip align="center"/>
      <el-table-column prop="address" label="收货地址信息" width="250px" show-overflow-tooltip align="center"/>
      <el-table-column prop="orderNo" label="订单号" show-overflow-tooltip align="center" width="250"/>
      <el-table-column prop="" label="订单状态" show-overflow-tooltip align="center">
        <template slot-scope="scope">
          <span>{{scope.row.status == 0 ? '待发货' : scope.row.status == 1 ? '已发货' : scope.row.status == -1 ? '不发货' : '已签收'}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="totalPrices" label="订单价格" show-overflow-tooltip align="center"/>
      <el-table-column prop="payTime" label="订单支付时间" width="150px" show-overflow-tooltip align="center"/>
      <el-table-column prop="deliveryTime" label="订单发货时间" width="150px" show-overflow-tooltip align="center"/>
      <el-table-column prop="lastUpdateTime" label="修改时间" width="150px" show-overflow-tooltip align="center"/>
      <el-table-column prop="remark" label="订单备注" width="150px" show-overflow-tooltip align="center"/>
      <el-table-column label="操作" align="center" width="300px"  fixed="right">
        <template slot-scope="scope">
          <el-button type="primary" size="small" @click="addOrModify(scope.row,'modify')">修改订单</el-button>
          <el-button type="primary" size="small" @click="addOrModify(scope.row, 'add')">新增物流</el-button>
          <el-button type="primary" size="small" @click="listLogistics(scope.row)">查询物流</el-button>
        </template>
      </el-table-column>
    </el-table>

    <Pagination
      v-show="total>0"
      :page-sizes="[20,50,100,200,500]"
      :total="total"
      :page.sync="queryList.pageNumber"
      :limit.sync="queryList.pageSize"
      @pagination="query"
    />
    <!--      新增 修改 弹窗-->
    <el-dialog :title="dialog.title" :visible.sync="dialog.dialogFormVisible" width="750px">
      <el-form :model="form" label-width="150px">
        <el-form-item label="订单状态:" v-if="dialog.type != 'add'">
          <el-select v-model="form.status" placeholder="请选择" style="width: 120px;">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"/>
          </el-select>
        </el-form-item>
        <el-form-item label="备注:">
          <el-input
            :rows="4"
            v-model="form.remark"
            type="textarea"
            placeholder="请输入内容"/>
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialog.dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addOrModifySubmit">确 定</el-button>
      </div>
    </el-dialog>

    <el-dialog title="所有物流状态" :visible.sync="dialogTableVisible">
      <el-table :data="list2">
        <el-table-column type="index" width="50"/>
        <el-table-column property="logisticNo" show-overflow-tooltip align="center" label="物流编号"></el-table-column>
        <el-table-column property="orderNo" show-overflow-tooltip align="center" label="订单编号"></el-table-column>
        <el-table-column property="createTime" show-overflow-tooltip align="center" label="创建时间"></el-table-column>
        <el-table-column property="remark" show-overflow-tooltip align="center" label="明细"></el-table-column>
      </el-table>
    </el-dialog>

  </div>
</template>

<script>
    import {listUserOrderPage, updateUserOrder, save, listLogistics, listProductType} from '@/api/modules/order-manage'

    import Pagination from '@/components/Pagination'
    import {pickOptions} from '@/config/index'

    export default {
        name: 'OrderManage',
        components: {Pagination},
        data() {
            return {
                pickOptions,
                timeRange: [],
                options: [// 订单状态
                    {value: 0, label: '待发货'},
                    {value: 1, label: '已发货'},
                    {value: -1, label: '不发货'},
                    {value: 2, label: '已签收'}
                ],
                queryList: {
                    typeName: '',
                    status: '',
                    productName: '',
                    pageSize: 20,
                    pageNumber: 1
                },
                list: [],
                list2: [],
                listProduct: [],
                listLoading: false,
                total: 0,
                dialogTableVisible: false,
                dialog: {
                    type: '',
                    title: '',
                    dialogFormVisible: false
                },

                form: {
                    remark: '',
                    orderNo: '',
                },
                multipleSelection: []
            }
        },
        created() {
            this.listProductType()
            this.query()
        },
        methods: {
            query(val) {
                if (val == 'btn') {
                    this.queryList.pageNumber == 1
                }
                this.queryList.startDate = this.timeRange ? this.timeRange[0] : ''
                this.queryList.endDate = this.timeRange ? this.timeRange[1] : ''
                this.listLoading = true
                listUserOrderPage(this.queryList).then(({code, data}) => {
                    this.list = data.list
                    this.total = data.total
                }).catch(e => {
                     this.$message.error(e.msg)
                }).finally(() => (this.listLoading = false))
            },
            listProductType(){
                listProductType().then(({code, data}) => {
                    this.listProduct = data
                }).catch(e => {
                     this.$message.error(e.msg)
                })
            },
            // 查询物流
            listLogistics(row){
                listLogistics({orderNo:row.orderNo}).then(({code, data}) => {
                    this.list2 = data
                    this.dialogTableVisible = true
                }).catch(e => {
                     this.$message.error(e.msg)
                })
            },
            // 新增 修改 任务设置 按钮
            addOrModifySubmit() {
                let api = null, query={} ;
                if (this.dialog.type == 'modify') {
                    query.status = this.form.status
                    query.list = [this.form.orderNo]
                    api = updateUserOrder

                }else if (this.dialog.type == 'batch') {
                    query.status = this.form.status
                    query.list =  this.multipleSelection.map(item => item.orderNo)
                    api = updateUserOrder
                } else {
                    query = this.form
                    api = save
                }
                api(query).then(({code}) => {
                    code == 200 && this.$message.success(this.dialog.title + '成功') && this.query()
                }).catch(e => {
                    this.$message.error(e.msg)
                })

                this.dialog.dialogFormVisible = false
            },
            // 新增 修改 任务设置 弹窗
            addOrModify(row,item) {

                if (item == 'modify') {
                    this.multipleSelection = []
                    this.dialog.type = 'modify'
                    this.dialog.title = '修改订单状态'
                    this.form = Object.assign({},row)
                    this.dialog.dialogFormVisible = true
                }else if (item == 'batch') {
                    this.resetFrom()
                    if (this.multipleSelection.length > 0){
                        this.dialog.type = 'batch'
                        this.dialog.title = '批量修改订单状态'
                        this.dialog.dialogFormVisible = true
                    }else {
                        this.$message.info('请先选择订单')
                    }

                } else {
                    this.resetFrom()
                    this.multipleSelection = []
                    this.dialog.type = 'add'
                    this.dialog.title = '新增订单状态'
                    this.form.orderNo = row.orderNo
                    this.dialog.dialogFormVisible = true
                }
            },
            resetFrom() {
                delete this.form.id
                this.form.remark = ''
                this.form.orderNo = ''
            },
            handleSelectionChange(val) {
                this.multipleSelection = val;
            }

        }
    }
</script>

<style scoped>

</style>
