import { setTheme } from '@/utils/auth'

export const global = {
  // 换肤添加class函数
  toggleClass(element, className) {
    if (!element || !className) {
      return
    }
    element.className = className
    setTheme(className)
  },
  // 切换主题函数
  changeTheme(themeValue) {
    // 需要移到单独的文件存放
    const itemPath = `./static/theme/${themeValue}/index.css`
    loadCss(themeValue, itemPath)

    function loadCss(value, path) {
      const allLinks = document.querySelectorAll('link[data-theme]')
      let flag = false;
      [].forEach.call(allLinks, link => {
        const theme = link.dataset.theme
        if (theme === value) {
          link.disabled = false
          flag = true
        } else {
          link.disabled = true
        }
      })
      if (!flag) {
        const head = document.getElementsByTagName('head')[0]
        const link = document.createElement('link')
        link.href = path
        link.rel = 'stylesheet'
        link.type = 'text/css'
        link.setAttribute('data-theme', value)
        head.appendChild(link)
      }
    }

    // function loadCss(path) {
    //   const head = document.getElementsByTagName('head')[0]
    //   const link = document.createElement('link')
    //   link.href = path
    //   link.rel = 'stylesheet'
    //   link.type = 'text/css'
    //   head.appendChild(link)
    // }
  },

  // 设置模态框宽度
  setModalWith() {
    const head = document.getElementsByTagName('head')[0]
    const link = document.createElement('link')
    link.href = './static/modal/modal.css'
    link.rel = 'stylesheet'
    link.type = 'text/css'
    head.appendChild(link)
  },

  // 修改css变量
  changeSideBar(opened) {
    const width = opened ? '180px' : '36px'
    const docStyle = document.documentElement.style
    docStyle.setProperty('--side-bar-width', width)
  }
}
