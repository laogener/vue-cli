<template>
  <div class="app-container">
    <el-row>
      <el-form ref="form" :inline="true" size="small" class="has-report-form-search">
        <el-form-item>
          <el-date-picker
            v-model="timeRange"
            :picker-options="pickOptions"
            :default-time="['00:00:00', '23:59:59']"
            unlink-panels
            style="width:380px"
            clearable
            type="datetimerange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            align="right"
            value-format="yyyy-MM-dd HH:mm:ss"
          />
        </el-form-item>
        <el-form-item>
          <el-input v-model="queryList.userAccount" placeholder="会员账号" clearable/>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="query('btn')">搜索</el-button>
        </el-form-item>
      </el-form>
    </el-row>
    <el-table v-loading="listLoading" :data="list" :height="tableHeight + 70" border fit highlight-current-row
              style="width: 100%;">
      <el-table-column type="index" width="50"/>
      <el-table-column prop="createTime" label="日期" show-overflow-tooltip align="center"/>
      <el-table-column prop="userAccount" label="会员账号" show-overflow-tooltip align="center"/>
      <el-table-column prop="score" label="获得积分" show-overflow-tooltip align="center"/>
      <el-table-column prop="beforeScore" label="操作前积分" show-overflow-tooltip align="center"/>
      <el-table-column prop="balance" label="操作后积分" show-overflow-tooltip align="center"/>
      <el-table-column prop="typeName" label="操作类型" show-overflow-tooltip align="center"/>
      <el-table-column prop="remark" label="描述" show-overflow-tooltip align="center"/>
    </el-table>

    <Pagination
      v-show="total>0"
      :page-sizes="[20,50,100,200,500]"
      :total="total"
      :page.sync="queryList.pageNum"
      :limit.sync="queryList.pageSize"
      @pagination="query"
    />

  </div>
</template>

<script>
    import {getUserScoreLog} from '@/api/modules/attendance/points-record-query'
    import Pagination from '@/components/Pagination'
    import {pickOptions} from '@/config/index'

    export default {
        name: 'points-record-query',
        components: {Pagination},
        data() {
            return {
                queryList: {
                    userAccount:'',
                    pageSize: 20,
                    pageNum: 1
                },
                pickOptions,
                timeRange: [],
                list: [],
                listLoading: false,
                total: 0,

            }
        },
        created() {
            this.timeRange = [this.formatDate(new Date()) + ' 00:00:00', this.formatDate(new Date()) + ' 23:59:59'];
            this.query()
        },
        methods: {
            query(val) {
                if (val == 'btn') {
                    this.queryList.pageNum == 1
                }
                this.queryList.startTime = this.timeRange ? this.timeRange[0] : ''
                this.queryList.endTime = this.timeRange ? this.timeRange[1] : ''
                this.listLoading = true
                getUserScoreLog(this.queryList).then(({code, data}) => {
                    this.list = data.list
                    this.total = data.total
                }).catch(e => {
                    this.$message.error(e.msg)
                }).finally(() => (this.listLoading = false))
            },
            formatDate(date) {
                var y = date.getFullYear();
                var m = date.getMonth() + 1;
                m = m < 10 ? '0' + m : m;
                var d = date.getDate();
                d = d < 10 ? ('0' + d) : d;
                return y + '-' + m + '-' + d;
            }
        }
    }
</script>

<style scoped>

</style>
