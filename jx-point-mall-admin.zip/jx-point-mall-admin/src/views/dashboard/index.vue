<template>
  <div class="dashboard-container">首页</div>
</template>

<script>

export default {
  name: 'Dashboard',
  data() {
    return {}
  }
}
</script>
