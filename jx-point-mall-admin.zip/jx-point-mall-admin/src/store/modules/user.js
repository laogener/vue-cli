import { login, logout } from '@/api/login'
import { getToken, setToken, removeToken, getSiteCode, setSiteCode, removeSiteCode, getAccount, setAccount, removeAccount, getMenuList, setMenuList, removeMenuList } from '@/utils/auth'
import routerArr from '@/routerArr'
const user = {
  state: {
    name: getAccount(),
    siteCode: getSiteCode(),
    token: getToken(),
    menuList: getMenuList()
  },
  mutations: {
    SET_USER_INFO: (state, payload) => {
      state.name = payload.account
      state.menuList = getMenuList()
      state.siteCode = payload.siteCode
      state.token = payload.token
    }
  },
  actions: {
    // 用户名登录
    LoginByUsername({ commit }, userInfo) {
      userInfo.account = userInfo.account.trim()
      return new Promise((resolve, reject) => {
        login(userInfo).then(res => {
          setSiteCode(res.data.siteCode)
          setAccount(res.data.account)
          setToken(res.data.token)
          setMenuList(routerArr)
          commit('SET_USER_INFO', res.data)
          resolve()
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 登出
    LogOut({ commit, state }) {
      return new Promise((resolve, reject) => {
        logout({ account: state.name }).then(res => {
          removeToken()
          removeSiteCode()
          removeAccount()
          removeMenuList()
          resolve()
        })
      })
    },

    // 前端 登出
    FedLogOut({ commit }) {
      return new Promise(resolve => {
        removeToken()
        removeSiteCode()
        removeAccount()
        removeMenuList()
        resolve()
      })
    }

  }
}

export default user
