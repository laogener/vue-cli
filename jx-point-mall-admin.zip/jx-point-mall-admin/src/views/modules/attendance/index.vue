<template>
  <div>签到管理</div>
</template>

<script>
export default {
  name: 'Index'
}
</script>

<style scoped>

</style>
