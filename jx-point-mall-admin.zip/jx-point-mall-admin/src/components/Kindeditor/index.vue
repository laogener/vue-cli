<template>
  <div>
    <editor
      :id="editorId"
      :items="items"
      :height="`${ height }px`"
      :width="`${ width }px`"
      :content="editorText"
      pluginsPath="/static/kindeditor/plugins/"
      :loadStyleMode="false"
      :uploadJson="uploadUrl"
      :filterMode="false"
      :extraFileUploadParams="data"
      @on-content-change="onContentChange"
    ></editor>
  </div>
</template>

<script>
    import { HOST_LIST } from '@/config'
export default {
  name: 'Kindeditor',
  components: {},
  props: {
    id: {
      type: String,
      default: function() {
        return (
          'editor_id_' + +new Date() + ((Math.random() * 1000).toFixed(0) + '')
        );
      },
    },
    uploadUrl: {
      type: String,
      default: `${HOST_LIST[process.env.ENV_CONFIG]['server1']}/score/signRuleCfg/uploadFile`,
    },
    data: {
      type: Object,
      default: function() {
        return {};
      },
    },
    items: {
      type: Array,
      default: function() {
        return [
          'formatblock',
          'fontname',
          'fontsize',
          '|',
          'forecolor',
          'hilitecolor',
          'bold',
          'italic',
          'underline',
          '|',
          'justifyleft',
          'justifycenter',
          'justifyright',
          'justifyfull',
          'insertorderedlist',
          'insertunorderedlist',
          'table',
          '|',
          'emoticons',
          'image',
          'link',
          '|',
          'removeformat',
          'undo',
          'redo',
          'source',
          'preview',
        ];
      },
    },
    value: {
      type: String,
      default: '',
    },
    height: {
      type: [Number, String],
      required: false,
      default: 360,
    },
    width: {
      type: [Number, String],
      required: false,
      default: 700,
    },
  },
  watch: {
    value(val) {
      this.editorText = val;
    },
  },
  data() {
    return {
      editorId: this.id,
      editorText: '',
    };
  },
  created() {
    this.editorText = this.value;
  },
  methods: {
    onContentChange(val) {
        console.log(111)
        console.log(val)
      this.editorText = val;
      this.$emit('input', val);
    },
  },
};
</script>
