import moment from 'moment'

// export const SERVERS_HOST = process.env.NODE_ENV === 'production' ? `//${document.location.host}${process.env.SERVICES_API}` : process.env.SERVICES_API
//
// export const WEBSOCKET_HOST = process.env.NODE_ENV === 'production' ? `${document.location.host}/back` : process.env.ADMIN_API.replace('//', '')

export const pickOptions = {
  shortcuts: [{
    text: '今天',
    onClick(picker) {
      const today = moment().format('YYYY-MM-DD')
      picker.$emit('pick', [new Date(`${today} 00:00:00`), new Date(`${today} 23:59:59`)])
    }
  }, {
    text: '前一天',
    onClick(picker) {
      const start = moment(picker.minDate).subtract(1, 'days').format('YYYY-MM-DD')
      picker.$emit('pick', [new Date(`${start} 00:00:00`), new Date(`${start} 23:59:59`)])
    }
  }, {
    text: '后一天',
    onClick(picker) {
      const start = moment(picker.minDate).add(1, 'days').format('YYYY-MM-DD')
      picker.$emit('pick', [new Date(`${start} 00:00:00`), new Date(`${start} 23:59:59`)])
    }
  }, {
    text: '本月',
    onClick(picker) {
      const start = moment().startOf('month').format('YYYY-MM-DD')
      const end = moment().endOf('month').format('YYYY-MM-DD')
      picker.$emit('pick', [new Date(`${start} 00:00:00`), new Date(`${end} 23:59:59`)])
    }
  }, {
    text: '上个月',
    onClick(picker) {
      let startTime = picker.minDate
      if (!picker.minDate) startTime = new Date().getTime()
      const start = moment(startTime).subtract(1, 'month').startOf('month').format('YYYY-MM-DD')
      const end = moment(startTime).subtract(1, 'month').endOf('month').format('YYYY-MM-DD')
      picker.$emit('pick', [new Date(`${start} 00:00:00`), new Date(`${end} 23:59:59`)])
    }
  }, {
    text: '下个月',
    onClick(picker) {
      let startTime = picker.minDate
      if (!picker.minDate) startTime = new Date().getTime()
      const start = moment(startTime).add(1, 'month').startOf('month').format('YYYY-MM-DD')
      const end = moment(startTime).add(1, 'month').endOf('month').format('YYYY-MM-DD')
      picker.$emit('pick', [new Date(`${start} 00:00:00`), new Date(`${end} 23:59:59`)])
    }
  }]
}

export const HOST_LIST = {
  dev: {
    server1: '//3.112.44.27:8010',
    server2: '//3.112.44.27:8020'
  },
  prod: {
    server1: '/score',
    server2: '/mall'
  },
  sit: {
    server1: '//18.177.114.102/score',
    server2: '//18.177.114.102/mall'
  }
}
