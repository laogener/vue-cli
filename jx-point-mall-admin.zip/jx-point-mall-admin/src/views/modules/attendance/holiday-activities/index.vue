<template>
  <div class="app-container">
    <el-row>
      <el-form ref="form" :inline="true" size="small" class="has-report-form-search">
        <el-form-item>
          <el-input v-model="queryList.signDay" placeholder="签到天数" clearable/>
        </el-form-item>
        <el-form-item>
          <el-input v-model="queryList.activityName" placeholder="活动名称" clearable/>
        </el-form-item>
        <el-form-item>
          <el-date-picker
            v-model="timeRange"
            :picker-options="pickOptions"
            :default-time="['00:00:00', '23:59:59']"
            unlink-panels
            style="width:380px"
            clearable
            type="datetimerange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            align="right"
            value-format="yyyy-MM-dd HH:mm:ss"
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="query('btn')">搜索</el-button>
          <el-button type="primary" icon="el-icon-plus" @click="addOrModify()">新增</el-button>
        </el-form-item>
      </el-form>
    </el-row>
    <el-table v-loading="listLoading" :data="list" :height="tableHeight + 70" border fit highlight-current-row
              style="width: 100%;">
      <el-table-column type="index" width="50"/>
      <el-table-column prop="activityName" label="活动名称" show-overflow-tooltip align="center"/>
      <el-table-column prop="remark" label="活动描述" show-overflow-tooltip align="center" width="200"/>
      <el-table-column prop="" label="PC图片" align="center" width="150">
        <template slot-scope="scope">
          <img :src="scope.row.pcPic" alt="" width="80">
        </template>
      </el-table-column>
      <el-table-column prop="" label="WAP图片" align="center" width="150">
        <template slot-scope="scope">
          <img :src="scope.row.wapPic" alt="" width="80">
        </template>
      </el-table-column>

      <el-table-column prop="noticeDate" label="预告日期" show-overflow-tooltip align="center" width="150"/>
      <el-table-column prop="startDate" label="开始日期" show-overflow-tooltip align="center" width="150"/>
      <el-table-column prop="endDate" label="结束日期" show-overflow-tooltip align="center" width="150"/>
      <el-table-column prop="pcUrl" label="链接地址pc" show-overflow-tooltip align="center" width="250"/>
      <el-table-column prop="wapUrl" label="链接地址wap" show-overflow-tooltip align="center" width="250"/>
      <el-table-column prop="signDay" label="签到天数" show-overflow-tooltip align="center"/>
      <el-table-column prop="" label="创建时间" show-overflow-tooltip align="center" width="150">
        <template slot-scope="scope">{{ scope.row.createTime | timeFmtFilter }}</template>
      </el-table-column>
      <el-table-column prop="createBy" label="创建者" show-overflow-tooltip align="center"/>
      <el-table-column prop="" label="修改时间" show-overflow-tooltip align="center" width="150">
        <template slot-scope="scope">{{ scope.row.updateTime | timeFmtFilter }}</template>
      </el-table-column>
      <el-table-column prop="userAccount" label="修改账号" show-overflow-tooltip align="center"/>

      <el-table-column label="操作" align="center" width="150px" fixed="right">
        <template slot-scope="scope">
          <el-button type="primary" size="small" @click="addOrModify(scope.row)">修改</el-button>
          <el-button type="primary" size="small" @click="del(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <Pagination
      v-show="total>0"
      :page-sizes="[20,50,100,200,500]"
      :total="total"
      :page.sync="queryList.pageNum"
      :limit.sync="queryList.pageSize"
      @pagination="query"
    />
    <!--      新增 修改 弹窗-->
    <el-dialog :title="dialog.title" :visible.sync="dialog.dialogFormVisible" width="750px">
      <el-form :model="form" label-width="150px">
        <el-form-item label="活动名称:">
          <el-input v-model="form.activityName" placeholder="限12个汉字" style="width: 380px;" clearable/>
        </el-form-item>
        <el-form-item label="活动描述:">
          <el-input :rows="4" v-model="form.remark" type="textarea" placeholder="限50个汉字" style="width: 380px;"/>
        </el-form-item>
        <el-form-item label="预告日期:">
          <el-date-picker v-model="form.noticeDate" type="datetime" placeholder="选择日期时间" default-time="00:00:00"  value-format="yyyy-MM-dd HH:mm:ss"/>
        </el-form-item>
        <el-form-item label="活动日期:">
          <el-date-picker
            v-model="timeRange2"
            :picker-options="pickOptions"
            :default-time="['00:00:00', '23:59:59']"
            unlink-panels
            style="width:380px"
            clearable
            unlink-panels
            type="datetimerange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            align="right"
            value-format="yyyy-MM-dd HH:mm:ss"
          />
        </el-form-item>
        <el-form-item label="链接地址pc:">
          <el-input v-model="form.pcUrl" style="width: 380px;" clearable/>
        </el-form-item>
        <el-form-item label="链接地址wap:">
          <el-input v-model="form.wapUrl" style="width: 380px;" clearable/>
        </el-form-item>
        <el-form-item label="PC图片:">
          <el-upload
            :action="`${uploadHost}/score/signRuleCfg/uploadFile`"
            :show-file-list="false"
            :data="{siteCode: getSiteCode,fileDir:'sign'}"
            :on-success="(value)=> handleSuccess(value,'pc')"
            :on-error="onUploadFileError"
            class="avatar-uploader margin-top-15"
          >
            <img v-if="form.pcPic" :src="form.pcPic" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"/>
          </el-upload>
        </el-form-item>
        <el-form-item label="WAP图片:">
          <el-upload
            :action="`${uploadHost}/score/signRuleCfg/uploadFile`"
            :show-file-list="false"
            :data="{siteCode: getSiteCode,fileDir:'sign'}"
            :on-success="handleSuccess"
            :on-error="onUploadFileError"
            class="avatar-uploader margin-top-15"
          >
            <img v-if="form.wapPic" :src="form.wapPic" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"/>
          </el-upload>
        </el-form-item>
        <el-form-item label="签到天数:">
          <el-input v-model="form.signDay" placeholder="签到天数" style="width: 380px;" type="number" clearable/>
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialog.dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addOrModifySubmit">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
    import {
        saveActivityCfg,
        removeActivityCfg,
        updateActivityCfg,
        findActivityCfgPage
    } from '@/api/modules/attendance/holiday-activities'
    import Pagination from '@/components/Pagination'
    import {getAccount, getSiteCode} from '@/utils/auth'
    import {pickOptions} from '@/config/index'
    import {formatDate} from '@/utils'
    import { HOST_LIST } from '@/config'

    export default {
        name: 'HolidayActivities',
        components: {Pagination},
        filters: {
            timeFmtFilter(value) {
                return formatDate(new Date(value), 'yyyy-MM-dd hh:mm:ss')
            }
        },
        computed: {
            uploadHost() {
                return HOST_LIST[process.env.ENV_CONFIG]['server1']
            },
            getSiteCode() {
                return getSiteCode()
            }
        },
        data() {
            return {
                pickOptions,
                timeRange: [],
                timeRange2: [],
                queryList: {
                    signDay: '',
                    activityName: '',
                    pageSize: 20,
                    pageNum: 1
                },
                list: [],
                listLoading: false,
                total: 0,
                dialog: {
                    type: '',
                    title: '',
                    dialogFormVisible: false
                },

                dialogImageUrl: '',
                dialogVisible: false,
                disabled: false,

                signDay: 1,
                form: {
                    activityName: '',
                    remark: '',
                    noticeDate: '',
                    // activityPic: '',
                    pcPic: '',
                    wapPic: '',
                    pcUrl: '',
                    wapUrl: '',
                    signDay: '',
                    updateBy: '',
                    createBy: '',
                    userAccount: '',
                }
            }
        },
        created() {
            this.query()
        },
        methods: {
            query(val) {
                if (val == 'btn') {
                    this.queryList.pageNum == 1
                }
                this.queryList.startDate = this.timeRange ? this.timeRange[0] : ''
                this.queryList.endDate = this.timeRange ? this.timeRange[1] : ''

                this.listLoading = true
                findActivityCfgPage(this.queryList).then(({code, data}) => {
                    this.list = data.list
                    this.total = data.total
                }).catch(e => {
                     this.$message.error(e.msg)
                }).finally(() => (this.listLoading = false))
            },
            // 新增 修改 任务设置 按钮
            addOrModifySubmit() {
                if (!this.form.activityName || this.form.activityName.length > 12) {
                    this.$message.info('请正确输入活动名称')
                    return false
                }
                if (!this.form.noticeDate) {
                    this.$message.info('请选择预告日期')
                    return false
                }
                if (this.timeRange2.length == 0) {
                    this.$message.info('请选择活动日期')
                    return false
                }
                if (!this.form.pcUrl) {
                    this.$message.info('请输入链接地址pc')
                    return false
                }
                if (!this.form.wapUrl) {
                    this.$message.info('请输入链接地址wap')
                    return false
                }
                if (!this.form.pcPic) {
                    this.$message.info('请上传PC图片')
                    return false
                }
                if (!this.form.wapPic) {
                    this.$message.info('请上传WAP图片')
                    return false
                }
                if (!this.form.signDay) {
                    this.$message.info('请输入签到天数')
                    return false
                }

                this.form.createBy = getAccount()
                this.form.userAccount = getAccount()
                this.form.startDate = this.timeRange2 ? this.timeRange2[0] : ''
                this.form.endDate = this.timeRange2 ? this.timeRange2[1] : ''
                let api = null, query = this.form
                if (this.dialog.type == 'modify') {
                    api = updateActivityCfg
                } else {
                    api = saveActivityCfg
                }
                api(query).then(({code}) => {
                    code == 200 && this.$message.success(this.dialog.title + '成功') && this.query()
                }).catch(e => {
                    this.$message.error(this.dialog.title + '失败')
                })
                this.dialog.dialogFormVisible = false
            },
            // 新增 修改 任务设置 弹窗
            addOrModify(row) {
                this.resetFrom()
                this.checkedGroup = []
                if (row) {
                    this.dialog.type = 'modify'
                    this.dialog.title = '修改活动'
                    this.timeRange2[0] = row.startDate
                    this.timeRange2[1] = row.endDate
                    Object.assign(this.form,row)
                } else {
                    this.dialog.type = 'add'
                    this.dialog.title = '新增活动'
                }
                this.dialog.dialogFormVisible = true
            },
            resetFrom() {
                delete this.form.id
                this.form.activityName = ''
                this.form.remark = ''
                this.form.noticeDate = ''
                this.form.pcPic = ''
                this.form.wapPic = ''
                this.form.pcUrl = ''
                this.form.wapUrl = ''
                this.form.signDay = ''
                this.form.userAccount = ''
                this.form.createBy = ''
                this.timeRange2 = []
            },
            del(row) {
                this.$confirm(
                    `<div>
        <div style="display: flex"><span style="width: 160px;text-align: right">活动名称：</span>${row.activityName}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">活动描述：</span>${row.remark}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">预告日期：</span>${row.noticeDate}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">开始日期：</span>${row.startDate}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">结束日期：</span>${row.endDate}</div>
      </div>`
                    , '确认删除？', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning',
                        dangerouslyUseHTMLString: true,
                        center: true
                    }).then(() => {
                    removeActivityCfg({id: row.id}).then(({code}) => {
                        code == 200 && this.$message.success('删除成功') && this.query()
                    }).catch(e => {
                        this.$message.error(e.msg)
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    })
                })
            },

            // 上传图片
            handleSuccess(res, item) {
                if (item == 'pc'){
                    this.form.pcPic = res.data || ''
                }else{
                    this.form.wapPic = res.data || ''
                }

            },
            onUploadFileError(err, file, fileList) {
                this.$message.error(err.msg || '上传图片失败')
            },
        }
    }
</script>

<style scoped>

</style>
