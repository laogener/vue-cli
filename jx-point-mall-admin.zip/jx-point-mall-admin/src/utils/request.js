import axios from 'axios'
import { Message } from 'element-ui'
import { removeToken, getToken, getSiteCode } from '@/utils/auth'
import { HOST_LIST } from '@/config'
import $store from '@/store'
import $router from '@/router'

const service = axios.create({
  timeout: 1000 * 60 * 5,
  headers: {
    post: {
      'Content-Type': 'application/json'
    }
  }
})

function assembleParam(url, param) {
  return JSON.stringify({
    token: getToken(),
    paramData: Object.assign({}, { siteCode: getSiteCode() }, param)
  })
}



service.interceptors.request.use(
  config => {
    config.baseURL = HOST_LIST[process.env.ENV_CONFIG][config.server]
    return Object.assign(config, {
      headers: Object.assign({}, config.headers,),
      data: assembleParam(config.url.replace(config.baseURL, ''), config.data || {})
    })
  },
  error => {
    Promise.reject(error)
  }
)

// response interceptor
service.interceptors.response.use(
  response => {
    const { code, msg, data } = response.data
    switch (Number(code)) {
      case 200:
      case 0:
        return response.data
      case 2001:
        console.log('%c __________$store:', 'color:red;', $store)
        removeToken()
        $router.push({ path: '/login' })
        return Promise.reject(response.data)
      default:
        Message.error(msg || data)
        return Promise.reject(response.data)
    }
  },
  error => {
    console.log(error)
    if (error.response) {
      Message({
        message: error.response.data.message || error.response.data.data,
        type: 'error',
        duration: 5 * 1000
      })
    } else {
      Message.error('响应超时,请稍后重试!')
    }
    return Promise.reject(error)
  }
)

export default service
