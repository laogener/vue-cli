import request from '@/utils/request'

// 添加焦点图
export function saveFocusPictureCfg(data) {
  return request({
    url: '/admin/picture/saveFocusPictureCfg',
    method: 'post',
    server: 'server2',
    data
  })
}
// 删除焦点图
export function delFocusPictureCfg(data) {
  return request({
    url: '/admin/picture/delFocusPictureCfg',
    method: 'post',
    server: 'server2',
    data
  })
}
// 修改焦点图
export function updateFocusPictureCfg(data) {
  return request({
    url: '/admin/picture/updateFocusPictureCfg',
    method: 'post',
    server: 'server2',
    data
  })
}
// 查询焦点图-分页
export function listFocusPictureCfgPage(data) {
  return request({
    url: '/admin/picture/listFocusPictureCfgPage',
    method: 'post',
    server: 'server2',
    data
  })
}
