module.exports = {
  NODE_ENV: '"development"',
  ENV_CONFIG: '"dev"',
  SERVICES_API: '"//3.112.44.27:8010"',
}
