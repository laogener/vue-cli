import { dictionary } from '@/api/dictionary'
import { setDict, getDict } from '@/utils/auth'
import { isString } from 'lodash'
const common = {
  state: {
    dictionary: getDict(),
    keepAlive: []
  },
  mutations: {
    SET_DIC: (state, dictionary) => {
      state.dictionary = dictionary
    },
    CHANGE_KEEP_ALIVE: (state, componentName) => {
      if (isString(componentName)) {
        !state.keepAlive.includes(componentName) && state.keepAlive.push(componentName)
      } else {
        state.keepAlive = state.keepAlive.filter(item => item !== componentName)
      }
    }
  },
  actions: {
    fetchDictAction({ commit }) {
      return new Promise(resolve => {
        dictionary().then(response => {
          commit('SET_DIC', response.currentData)
          setDict(response.currentData)
          resolve()
        }).catch(() => {
          resolve()
        })
      })
    }
  }
}
export default common
