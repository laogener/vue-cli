<template>
  <div class="app-container">
    <el-row>
      <el-form ref="form" :inline="true" size="small" class="has-report-form-search">
        <el-form-item label="商品分类:">
          <el-select v-model="queryList.typeNo" placeholder="请选择" style="width: 250px;">
            <el-option
              v-for="item in listProduct"
              :key="item.typeNo"
              :label="item.typeName"
              :value="item.typeNo"/>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="query('btn')">搜索</el-button>
          <el-button type="primary" icon="el-icon-plus" @click="addOrModify()">新增</el-button>
        </el-form-item>
      </el-form>
    </el-row>
    <el-table v-loading="listLoading" :data="list" :height="tableHeight + 70" border fit highlight-current-row
              style="width: 100%;">
      <el-table-column type="index" width="50"/>
      <el-table-column prop="name" label="商品名称" show-overflow-tooltip align="center"/>
      <el-table-column prop="model" label="商品型号" show-overflow-tooltip align="center"/>
      <el-table-column prop="typeName" label="类型名称" show-overflow-tooltip align="center" width="80"/>
      <el-table-column prop="recommendNo" label="推荐编号" show-overflow-tooltip align="center"/>
      <el-table-column prop="sortNo" label="排序编号" show-overflow-tooltip align="center" width="80"/>

      <el-table-column label="操作" align="center" width="150px">
        <template slot-scope="scope">
          <el-button type="primary" size="small" @click="del(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <Pagination
      v-show="total>0"
      :page-sizes="[20,50,100,200,500]"
      :total="total"
      :page.sync="queryList.pageNumber"
      :limit.sync="queryList.pageSize"
      @pagination="query"
    />
    <!--      新增 修改 弹窗-->
    <el-dialog :title="dialog.title" :visible.sync="dialog.dialogFormVisible" width="750px">
      <el-form :model="form" label-width="150px">
<!--        <el-form-item label="排序:">-->
<!--          <el-input v-model="form.sortNo" type="number" clearable/>-->
<!--        </el-form-item>-->


        <el-form-item label="板块名称:">
          <el-select v-model="form.typeNo" placeholder="请选择" style="width: 250px;">
            <el-option
              v-for="(item,index) in listProduct"
              :key="index"
              :label="item.typeName"
              :value="item.typeNo"/>
          </el-select>
        </el-form-item>
        <el-form-item label="板块下商品:">
          <el-select v-model="form.list" multiple style="width: 100%;" placeholder="请选择商品">
            <el-option
              v-for="(item,index) in listProduct2"
              :key="index"
              :label="item.name"
              :value="item.productNo">
            </el-option>
          </el-select>
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialog.dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addOrModifySubmit">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
    import {
        listRecommendCfgPage,
        saveRecommendCfg,
        listProductType,
        listProduct,
        delRecommendCfg
    } from '@/api/modules/home-content/classified-recommend'
    import Pagination from '@/components/Pagination'

    export default {
        name: 'ClassifiedRecommend',
        components: {Pagination},
        watch: {
            'form.typeNo': {
                immediate: true,
                handler(val) {
                    this.listProduct.map(item => {
                        item.typeNo == val && (this.form.typeName = item.typeName)
                    })
                    listProduct({typeNo:val}).then(({code, data}) => {
                        this.listProduct2 = data
                    }).catch(e => {
                         this.$message.error(e.msg)
                    })
                },
                deep:true
            },

        },
        data() {
            return {
                listProduct: [],
                listProduct2: [],
                queryList: {
                    typeNo:'',
                    pageSize: 20,
                    pageNumber: 1
                },
                list: [],
                listLoading: false,
                total: 0,
                dialog: {
                    type: '',
                    title: '',
                    dialogFormVisible: false
                },

                form: {
                    // sortNo: '',
                    typeNo: '',
                    typeName: '',
                    list: [],
                }
            }
        },
        created() {
            this.query()
            this.listProductType()
        },
        methods: {
            query(val) {
                if (val == 'btn') {
                    this.queryList.pageNumber == 1
                }
                this.listLoading = true
                listRecommendCfgPage(this.queryList).then(({code, data}) => {
                    this.list = data.list
                    this.total = data.total
                }).catch(e => {
                     this.$message.error(e.msg)
                }).finally(() => (this.listLoading = false))
            },
            listProductType(){
                listProductType().then(({code, data}) => {
                    this.listProduct = data
                }).catch(e => {
                     this.$message.error(e.msg)
                })
            },
            // 新增 修改 任务设置 按钮
            addOrModifySubmit() {
                // if (!this.form.typeNo) {
                //     this.$message.info('请输入排序')
                //     return false
                // }
                if (!this.form.typeNo) {
                    this.$message.info('请选择板块名称')
                    return false
                }
                if (!this.form.list) {
                    this.$message.info('请选择板块下商品')
                    return false
                }

                saveRecommendCfg(this.form).then(({code}) => {
                    code == 200 && this.$message.success(this.dialog.title + '成功') &&  this.query()
                }).catch(e => {
                    this.$message.error(e.msg)
                })
                this.dialog.dialogFormVisible = false
            },
            // 新增 修改 任务设置 弹窗
            addOrModify() {
                this.resetFrom()
                this.dialog.type = 'add'
                this.dialog.title = '新增板块和商品'
                this.dialog.dialogFormVisible = true
            },
            resetFrom() {
                delete this.form.id
                // this.form.sortNo = ''
                this.form.typeNo = ''
                this.form.typeName = ''
                this.form.list = []
            },
            del(row) {
                this.$confirm(
                    `<div>
        <div style="display: flex"><span style="width: 160px;text-align: right">商品名称：</span>${row.name}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">商品编号：</span>${row.productNo}</div>
       </div>`
                    , '确认删除？', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning',
                        dangerouslyUseHTMLString: true,
                        center: true
                    }).then(() => {
                    delRecommendCfg({recommendNo: row.recommendNo}).then(({code}) => {
                        code == 200 && this.$message.success('删除成功') &&  this.query()
                    }).catch(e => {
                        this.$message.error('删除失败')
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    })
                })
            }

        }
    }
</script>

<style scoped>

</style>
