<template>
  <div class="app-container">
    <el-form ref="dataForm" :rules="rules" :model="form" label-position="right" label-width="120px">
      <el-form-item label="账号" prop="pay_account">
        <el-input v-model="form.payAccount"/>
      </el-form-item>
      <el-form-item label="旧的提现密码" prop="site_code">
        <el-input v-model="form.siteCode"/>
      </el-form-item>
      <el-form-item label="新的提现密码" prop="day_max_count">
        <el-input v-model="form.dayMaxCount"/>
      </el-form-item>
      <el-form-item label="确认提现密码" prop="account_mode">
        <el-input v-model="form.siteCode"/>
      </el-form-item>
      <el-form-item>
        <el-button>保存提现密码</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import waves from '@/directive/waves'
import { list, add, update, del } from '@/api/business/pay/account-manage'
import tableMixin from '@/mixin/table'

export default {
  name: 'SettingWithdrawPassword',
  directives: {
    waves
  },
  mixins: [tableMixin],
  data() {
    return {
      rules: {},
      config: {
        add: add,
        del: del,
        update: update,
        list: list,
        form: {
          payAccount: '',
          siteCode: '',
          accountMode: 0,
          dayMaxCount: 0,
          dayMaxAmount: 0.00,
          maxAmount: 0.00,
          dayWarningCount: 0,
          dayWarningAmount: 0.00,
          warningAmount: 0.00,
          accountInitAmount: 0.00,
          accountActiveAmount: 0.00
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
  .demo-table-expand {
    font-size: 0;
  }
  .demo-table-expand label {
    width: 90px;
    color: #99a9bf;
  }
  .demo-table-expand .el-form-item {
    margin-right: 0;
    margin-bottom: 0;
    width: 50%;
  }
</style>
