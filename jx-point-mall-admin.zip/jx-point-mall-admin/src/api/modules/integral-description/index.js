import request from '@/utils/request'

// 查询说明列表
export function listHelpCfgPage(data) {
  return request({
    url: '/admin/help/listHelpCfgPage',
    method: 'post',
    server: 'server2',
    data
  })
}


// 新增说明
export function saveHelpCfg(data) {
  return request({
    url: '/admin/help/saveHelpCfg',
    method: 'post',
    server: 'server2',
    data
  })
}
// 修改说明
export function updateHelpCfg(data) {
  return request({
    url: '/admin/help/updateHelpCfg',
    method: 'post',
    server: 'server2',
    data
  })
}
// 删除说明
export function delHelpCfg(data) {
  return request({
    url: '/admin/help/delHelpCfg',
    method: 'post',
    server: 'server2',
    data
  })
}

