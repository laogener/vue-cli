import request from '@/utils/request'

// 配置闪购
export function updateDiscountsCfg(data) {
  return request({
    url: '/admin/discounts/updateDiscountsCfg',
    method: 'post',
    server: 'server2',
    data
  })
}
// 查询闪购配置-不分页
export function listDiscountsCfg(data) {
  return request({
    url: '/admin/discounts/listDiscountsCfg',
    method: 'post',
    server: 'server2',
    data
  })
}
// 查询闪购配置-不分页
export function listDiscountsCfgPage(data) {
  return request({
    url: '/admin/discounts/listDiscountsCfgPage',
    method: 'post',
    server: 'server2',
    data
  })
}
// 查询商品分类
export function listProductType(data) {
  return request({
    url: '/admin/type/listProductType',
    method: 'post',
    server: 'server2',
    data
  })
}
