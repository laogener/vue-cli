import request from '@/utils/request'

// 添加商品分类
export function saveProductType(data) {
  return request({
    url: '/admin/type/saveProductType',
    method: 'post',
    server: 'server2',
    data
  })
}
// 修改商品分类
export function updateProductType(data) {
  return request({
    url: '/admin/type/updateProductType',
    method: 'post',
    server: 'server2',
    data
  })
}
// 删除商品分类
export function delProduct(data) {
  return request({
    url: '/admin/type/delProductType',
    method: 'post',
    server: 'server2',
    data
  })
}
// 查询商品类型-分页
export function listProductTypePage(data) {
  return request({
    url: '/admin/type/listProductTypePage',
    method: 'post',
    server: 'server2',
    data
  })
}

