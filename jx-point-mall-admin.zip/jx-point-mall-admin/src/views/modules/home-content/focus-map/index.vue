<template>
  <div class="app-container">
    <el-row>
      <el-form ref="form" :inline="true" size="small" class="has-report-form-search">
        <el-form-item label="终端:">
          <el-select v-model="queryList.terminal" placeholder="请选择" style="width: 100px;">
            <el-option label="全部" value=""/>
            <el-option
              v-for="item in options"
              :key="item"
              :label="item"
              :value="item"/>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="query('btn')">搜索</el-button>
          <el-button type="primary" icon="el-icon-plus" @click="addOrModify()">新增</el-button>
        </el-form-item>
      </el-form>
    </el-row>
    <el-table v-loading="listLoading" :data="list" :height="tableHeight + 70" border fit highlight-current-row
              style="width: 100%;">
      <el-table-column type="index" width="50"/>
      <el-table-column prop="name" label="标题名称" show-overflow-tooltip align="center"/>
      <el-table-column prop="terminal" label="终端" show-overflow-tooltip align="center"/>
      <el-table-column prop="url" label="跳转地址" show-overflow-tooltip align="center"/>
      <el-table-column prop="sortNo" label="排序编号" show-overflow-tooltip align="center"/>
      <el-table-column prop="lastUpdateTime" label="修改时间" show-overflow-tooltip align="center"/>
      <el-table-column prop="itemPic" label="图片" show-overflow-tooltip align="center">
        <template slot-scope="scope">
          <img :src="scope.row.imgUrl" alt="" width="80">
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" width="150px">
        <template slot-scope="scope">
          <el-button type="primary" size="small" @click="addOrModify(scope.row)">修改</el-button>
          <el-button type="primary" size="small" @click="del(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <Pagination
      v-show="total>0"
      :page-sizes="[20,50,100,200,500]"
      :total="total"
      :page.sync="queryList.pageNumber"
      :limit.sync="queryList.pageSize"
      @pagination="query"
    />
    <!--      新增 修改 弹窗-->
    <el-dialog :title="dialog.title" :visible.sync="dialog.dialogFormVisible" width="750px">
      <el-form :model="form" label-width="150px">
        <el-form-item label="焦点图名称:">
          <el-input v-model="form.name" clearable/>
        </el-form-item>
        <el-form-item label="跳转类型:">
          <el-select v-model="form.type" placeholder="请选择" style="width: 200px;">
            <el-option
              v-for="item in options2"
              :key="item.value"
              :label="item.label"
              :value="item.value"/>
          </el-select>
        </el-form-item>
        <el-form-item label="跳转地址:">
          <el-input v-model="form.url" clearable/>
        </el-form-item>
        <el-form-item label="排序:">
          <el-input v-model="form.sortNo" type="number" clearable/>
        </el-form-item>
        <el-form-item label="终端:">
          <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选
          </el-checkbox>
          <div style="margin: 15px 0;"/>
          <el-checkbox-group v-model="checkedGroup" @change="handleCheckedChange">
            <el-checkbox v-for="item in options" :label="item" :key="item"
                         style="width: 160px;margin-left: 0px;margin-right: 10px">{{ item }}
            </el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="图片:">
          <el-upload
            :action="`${uploadHost}/score/signRuleCfg/uploadFile`"
            :show-file-list="false"
            :data="{siteCode: getSiteCode,fileDir:'integral'}"
            :on-success="handleSuccess"
            :on-error="onUploadFileError"
            :before-upload="beforeAvatarUpload"
            class="avatar-uploader margin-top-15"
          >
            <img v-if="form.imgUrl" :src="form.imgUrl" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"/>
          </el-upload>
          <span style="position: relative;top: -44px;left: 165px;color: #C0C4CC">Wap、App：375*140等比例大小；PC：970*460</span>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialog.dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addOrModifySubmit">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
    import {
        saveFocusPictureCfg,
        delFocusPictureCfg,
        updateFocusPictureCfg,
        listFocusPictureCfgPage
    } from '@/api/modules/home-content/focus-map'
    import Pagination from '@/components/Pagination'
    import {getSiteCode} from '@/utils/auth'
    import { HOST_LIST } from '@/config'

    export default {
        name: 'FocusMap',
        components: {Pagination},
        computed: {
            uploadHost() {
                return HOST_LIST[process.env.ENV_CONFIG]['server1']
            },
            getSiteCode() {
                return getSiteCode()
            }
        },
        data() {
            return {
                options: [// 签到天数
                    'wap','pc','app'
                ],
                options2: [// 跳转类型
                    {value: 1, label: '商品详情'},
                    {value: 2, label: '活动详情'},
                    {value: 3, label: '外链'},
                ],
                queryList: {
                    terminal: '',
                    pageSize: 20,
                    pageNumber: 1
                },
                list: [],
                listLoading: false,
                total: 0,
                dialog: {
                    type: '',
                    title: '',
                    dialogFormVisible: false
                },

                checkAll: false,
                checkedGroup: [],
                isIndeterminate: true,

                form: {
                    pictureCfgNO: '',
                    terminal: '',
                    name: '',
                    url: '',
                    imgUrl: '',
                    sortNo: 1,
                    type: 1,
                }
            }
        },
        created() {
            this.query()
        },
        methods: {
            query(val) {
                if (val == 'btn') {
                    this.queryList.pageNumber == 1
                }
                this.listLoading = true
                listFocusPictureCfgPage(this.queryList).then(({code, data}) => {
                    this.list = data.list
                    this.total = data.total
                }).catch(e => {
                     this.$message.error(e.msg)
                }).finally(() => (this.listLoading = false))
            },
            // 新增 修改 任务设置 按钮
            addOrModifySubmit() {
                if (!this.form.name) {
                    this.$message.info('请输入焦点图名称')
                    return false
                }
                if (!this.form.url) {
                    this.$message.info('请输入跳转地址')
                    return false
                }
                if (!this.form.sortNo) {
                    this.$message.info('排序从1开始')
                    return false
                }
                if (this.checkedGroup.length == 0) {
                    this.$message.info('请选择终端')
                    return false
                }
                if (!this.form.imgUrl) {
                    this.$message.info('请上传图片')
                    return false
                }

                this.form.terminal = this.checkedGroup.join(',');
                let api = null, query = this.form;
                if (this.dialog.type == 'modify') {
                    api = updateFocusPictureCfg
                } else {
                    api = saveFocusPictureCfg
                }
                api(query).then(({code}) => {
                    code == 200 && this.$message.success(this.dialog.title + '成功') && this.query()
                }).catch(e => {
                    this.$message.error(e.msg)
                })
                this.dialog.dialogFormVisible = false
            },
            // 新增 修改 任务设置 弹窗
            addOrModify(row) {
                if (row) {
                    this.dialog.type = 'modify'
                    this.dialog.title = '修改首页焦点图'
                    this.checkedGroup = row.terminal.split(',')
                    Object.assign(this.form,row)
                } else {
                    this.resetFrom()
                    this.dialog.type = 'add'
                    this.dialog.title = '新增首页焦点图'
                }
                this.dialog.dialogFormVisible = true
            },
            resetFrom() {
                delete this.form.id
                this.form.pictureCfgNO = ''
                this.form.terminal = ''
                this.form.name = ''
                this.form.url = ''
                this.form.imgUrl = ''
                this.form.sortNo = 1
                this.form.type = 1
                this.checkedGroup = []
                this.isIndeterminate = true
            },
            del(row) {
                this.$confirm(
                    `<div>
        <div style="display: flex"><span style="width: 160px;text-align: right">焦点图名称：</span>${row.name}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">跳转地址：</span>${row.url}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">排序：</span>${row.sortNo}</div>
       </div>`
                    , '确认删除？', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning',
                        dangerouslyUseHTMLString: true,
                        center: true
                    }).then(() => {
                    delFocusPictureCfg({pictureCfgNo: row.pictureCfgNo}).then(({code}) => {
                        code == 200 && this.$message.success('删除成功') && this.query()
                    }).catch(e => {
                        this.$message.error('删除失败')
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    })
                })
            },
            // 上传图片
            handleSuccess(res, file, fileList) {
                this.form.imgUrl = res.data || ''
            },
            onUploadFileError(err, file, fileList) {
                this.$message.error(err.msg || '上传图片失败')
            },
            beforeAvatarUpload(file) {
                const isLt5M = file.size / 1024 / 1024 < 5;

                if (!isLt5M) {
                    this.$message.error('上传头像图片大小不能超过 5MB!');
                }
                return isLt5M;
            },
            // checkbox
            handleCheckAllChange(val) {
                this.checkedGroup = val ? this.options : []
                this.isIndeterminate = false
            },
            handleCheckedChange(value) {
                const checkedCount = value.length
                this.checkAll = checkedCount === this.options.length
                this.isIndeterminate = checkedCount > 0 && checkedCount < this.options.length
            }
        }
    }
</script>

<style scoped>

</style>
