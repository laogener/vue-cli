import request from '@/utils/request'

// 新增任务设置
export function saveTaskCfg(data) {
  return request({
    url: '/score/task/saveTaskCfg',
    method: 'post',
    server: 'server1',
    data
  })
}
// 修改任务设置
export function updateTaskCfg(data) {
  return request({
    url: '/score/task/updateTaskCfg',
    method: 'post',
    server: 'server1',
    data
  })
}
// 删除任务设置
export function delTaskCfg(data) {
  return request({
    url: '/score/task/delTaskCfg',
    method: 'post',
    server: 'server1',
    data
  })
}
// 查询任务列表
export function findTaskCfg(data) {
  return request({
    url: '/score/task/findTaskCfg',
    method: 'post',
    server: 'server1',
    data
  })
}
// 编辑任务规则
export function editRuleCfg(data) {
  return request({
    url: '/score/task/editRuleCfg',
    method: 'post',
    server: 'server1',
    data
  })
}
// 查询任务规则
export function findRuleCfg(data) {
  return request({
    url: '/score/task/findRuleCfg',
    method: 'post',
    server: 'server1',
    data
  })
}
// 查询基础类型
export function findBasic(data) {
  return request({
    url: '/score/basic/findBasic',
    method: 'post',
    server: 'server1',
    data
  })
}
