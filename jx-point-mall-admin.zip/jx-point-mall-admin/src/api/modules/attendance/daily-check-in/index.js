import request from '@/utils/request'

// 新增签到规则
export function saveSignRuleCfg(data) {
  return request({
    url: '/score/signRuleCfg/saveSignRuleCfg',
    method: 'post',
    server: 'server1',
    data
  })
}
// 删除签到规则
export function removeSignRuleCfg(data) {
  return request({
    url: '/score/signRuleCfg/removeSignRuleCfg',
    method: 'post',
    server: 'server1',
    data
  })
}
// 修改签到规则
export function updateSignRuleCfg(data) {
  return request({
    url: '/score/signRuleCfg/updateSignRuleCfg',
    method: 'post',
    server: 'server1',
    data
  })
}
// 查询签到规则-分页
export function findSignRuleCfgPage(data) {
  return request({
    url: '/score/signRuleCfg/findSignRuleCfgPage',
    method: 'post',
    server: 'server1',
    data
  })
}
// 获取用户组接口
export function getSiteUserGroup(data) {
  return request({
    url: '/score/signRuleCfg/getSiteUserGroup',
    method: 'post',
    server: 'server1',
    data
  })
}
// 上传图片接口接口
export function uploadFile(data) {
  return request({
    url: '/score/signRuleCfg/uploadFile',
    method: 'post',
    server: 'server1',
    data
  })
}
