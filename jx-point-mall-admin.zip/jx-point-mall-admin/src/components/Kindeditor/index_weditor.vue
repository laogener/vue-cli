<template>
  <div ref="editor" class="e-editor" :style="styleObj"></div>
</template>

<script>
import E from 'wangeditor';
import { constants } from 'fs';
import { setTimeout } from 'timers';
import { HOST_LIST } from '@/config'

export default {
  name: 'Editor',
  props: {
    value: { type: String, default: "" },
    uploadUrl: {
      type: String,
      default: `${HOST_LIST[process.env.ENV_CONFIG]['server1']}/score/signRuleCfg/uploadFile`
    },
    height: { type: [Number, String], default: 330 },
    width: { type: [Number, String], default: 700 },
    data: { type: Object, default: () => ({}) },
    disable: { type: Boolean, default: false },
  },
  computed: {
    styleObj() {
      const reg = /[a-zA-Z]+/;
      const height = reg.test(this.height) ? this.height : this.height + 'px';
      const width = reg.test(this.width) ? this.width : this.width + 'px';
      return { height, width };
    },
  },
  data() {
    return {
      editor: null,
      content: '',
    };
  },
  watch: {
    value: {
      immediate: true,
      handler(val) {
        this.content = val;
        this.$nextTick(() => {
          this.editor && this.editor.txt.html(this.content);
        });
      },
    },
    disable: {
      immediate: true,
      handler(val) {
        this.$nextTick(() => {
          this.editor && this.editor.$textElem.attr('contenteditable', !val);
        });
      },
    },
  },
  methods: {
    createEditor() {
      this.editor = new E(this.$refs.editor);
      this.editor.customConfig.onchange = html => {
        this.content = html;
      };
      this.editor.customConfig.onblur = html => {
        this.content = '';
      };
      this.configMenu();
      if (this.uploadUrl) {
        this.configUpload();
      }
      this.editor.create();
    },
    configUpload() {
      const that = this;
      this.editor.customConfig.uploadImgServer = this.uploadUrl;
      this.editor.customConfig.uploadFileName = 'file';
      this.editor.customConfig.uploadImgParams = Object.assign({}, this.data);
      this.editor.customConfig.uploadImgHooks = {
        before: function(xhr, editor, files) {},
        // 图片上传并返回结果，图片插入成功之后触发
        success: function(xhr, editor, result) {},
        // 图片上传并返回结果，但图片插入错误时触发
        fail: function(xhr, editor, result) {},
        error: function(xhr, editor) {},
        timeout: function(xhr, editor) {},
        customInsert: function(insertImg, result, editor) {
          if (result && result.currentStatus == '200') {
            const url = result.currentData;
            insertImg(url);
          } else {
            that.$message.error('上传图片失败');
          }
        },
      };
      this.editor.customConfig.customAlert = info => {
        that.$message.error(info);
      };
    },
    configMenu() {
      this.editor.customConfig.colors = [
        '#000000',
        '#eeece0',
        '#cccccc',
        '#999999',
        '#1c487f',
        '#4d80bf',
        '#c24f4a',
        '#8baa4a',
        '#7b5ba1',
        '#46acc8',
        '#f9963b',
        '#ffffff',
      ];
      this.editor.customConfig.menus = [
        'head', // 标题
        'bold', // 粗体
        'fontSize', // 字号
        'fontName', // 字体
        'italic', // 斜体
        'underline', // 下划线
        'strikeThrough', // 删除线
        'foreColor', // 文字颜色
        'backColor', // 背景颜色
        'link', // 插入链接
        'list', // 列表
        'justify', // 对齐方式
        'quote', // 引用
        // "emoticon", // 表情
        'image', // 插入图片
        'table', // 表格
        // "video", // 插入视频
        'code', // 插入代码
        'undo', // 撤销
        'redo', // 重复
      ];
    },
    setContent() {
      this.editor && this.editor.txt.html(this.value);
    },
    getContent() {
      return this.editor.txt.html().replace(/<p><br><\/p>$/,'');
    }
  },
  mounted() {
    this.createEditor();
  },
};
</script>

<style scoped>
.e-editor >>> .w-e-text-container {
  height: calc(100% - 30px) !important;
}
</style>


