<template>
  <div>任务管理</div>
</template>

<script>
export default {
  name: 'Task',
  data() {
    return {}
  }
}
</script>

<style scoped>

</style>
