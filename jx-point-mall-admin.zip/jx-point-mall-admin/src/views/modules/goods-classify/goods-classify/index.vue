<template>
  <div class="app-container">
    <el-row>
      <el-form ref="form" :inline="true" size="small" class="has-report-form-search">
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="query('btn')">搜索</el-button>
          <el-button type="primary" icon="el-icon-plus" @click="addOrModify()">新增</el-button>
        </el-form-item>
      </el-form>
    </el-row>
    <el-table v-loading="listLoading" :data="list" :height="tableHeight + 70" border fit highlight-current-row
              style="width: 100%;">
      <el-table-column type="index" width="50"/>
      <el-table-column prop="typeName" label="类型名称" show-overflow-tooltip align="center"/>

      <el-table-column prop="" label="状态" show-overflow-tooltip align="center">
        <template slot-scope="scope">
          <span v-if="scope.row.status" style="color: #409EFF">启用</span>
          <span v-else style="color: #F56C6C">禁用</span>
        </template>
      </el-table-column>

      <el-table-column prop="sortNo" label="排序编号" show-overflow-tooltip align="center"/>
      <el-table-column prop="productNum" label="商品数" show-overflow-tooltip align="center"/>

      <el-table-column label="操作" align="center" width="150px">
        <template slot-scope="scope">
          <el-button type="primary" size="small" @click="addOrModify(scope.row)">修改</el-button>
          <el-button type="primary" size="small" @click="del(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <Pagination
      v-show="total>0"
      :page-sizes="[20,50,100,200,500]"
      :total="total"
      :page.sync="queryList.pageNumber"
      :limit.sync="queryList.pageSize"
      @pagination="query"
    />
    <!--      新增 修改 弹窗-->
    <el-dialog :title="dialog.title" :visible.sync="dialog.dialogFormVisible" width="500px">
      <el-form :model="form" label-width="150px">
        <el-form-item label="分类名称:">
          <el-input v-model="form.typeName" style="width: 200px;" clearable/>
        </el-form-item>
        <el-form-item label="分类排序:">
          <el-input v-model="form.sortNo" type="number" style="width: 200px;" clearable/>
        </el-form-item>
        <el-form-item label="状态:">
          <el-radio v-model="form.status" :label="true">启用</el-radio>
          <el-radio v-model="form.status" :label="false">禁用</el-radio>
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialog.dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addOrModifySubmit">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
import { saveProductType, updateProductType, delProduct, listProductTypePage } from '@/api/modules/goods-classify'
import Pagination from '@/components/Pagination'
import { getAccount } from '@/utils/auth'
import { pickOptions } from '@/config/index'

export default {
  name: 'GoodsClassify',
  components: { Pagination },
  data() {
    return {
      pickOptions,
      timeRange: [],
      timeRange2: [],
      queryList: {
        pageSize: 20,
        pageNumber: 1
      },
      list: [],
      listLoading: false,
      total: 0,
      dialog: {
        type: '',
        title: '',
        dialogFormVisible: false
      },

      signDay: 1,
      form: {
        typeName: '',
        status: true,
        sortNo: ''
      }
    }
  },
  created() {
    this.query()
  },
  methods: {
    query(val) {
      if (val == 'btn') {
        this.queryList.pageNumber == 1
      }

      this.listLoading = true
      listProductTypePage(this.queryList).then(({ code, data }) => {
        this.list = data.list
        this.total = data.total
      }).catch(e => {
         this.$message.error(e.msg)
      }).finally(() => (this.listLoading = false))
    },
    // 新增 修改 任务设置 按钮
    addOrModifySubmit() {
      if (!this.form.typeName) {
        this.$message.info('请输入分类名称')
        return false
      }
      if (!this.form.sortNo) {
        this.$message.info('请输入分类排序')
        return false
      }

      let api = null, query = this.form
      if (this.dialog.type == 'modify') {
        api = updateProductType
      } else {
        api = saveProductType
      }
      api(query).then(({ code }) => {
        code == 200 && this.$message.success(this.dialog.title + '成功') && this.query()
      }).catch(e => {
        this.$message.error(e.msg)
      })
      this.dialog.dialogFormVisible = false
    },
    // 新增 修改 任务设置 弹窗
    addOrModify(row) {
      if (row) {
        this.dialog.type = 'modify'
        this.dialog.title = '修改分类'
        Object.assign(this.form,row)
      } else {
          this.resetFrom()
        this.dialog.type = 'add'
        this.dialog.title = '新增分类'
      }
      this.dialog.dialogFormVisible = true
    },
    resetFrom() {
        delete this.form.id
      this.form.typeName = ''
      this.form.status = true
      this.form.sortNo = ''
    },
    del(row) {
      this.$confirm(
        `<div>
        <div style="display: flex"><span style="width: 160px;text-align: right">分类名称：</span>${row.typeName}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">包含商品数：</span>${row.productNum}个</div>
      </div>`
        , '确认删除商品分类？', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          dangerouslyUseHTMLString: true,
          center: true
        }).then(() => {
        delProduct({ typeNo: row.typeNo }).then(({ code }) => {
          code == 200 && this.$message.success('删除成功') && this.query()
        }).catch(e => {
          this.$message.error('删除失败')
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    }

  }
}
</script>

<style scoped>

</style>
