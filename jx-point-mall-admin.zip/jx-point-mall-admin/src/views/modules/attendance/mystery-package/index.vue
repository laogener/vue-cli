<template>
  <div class="app-container">
    <el-row>
      <el-form ref="form" :inline="true" size="small" class="has-report-form-search">
        <el-form-item label="签到天数:">
          <el-select v-model="queryList.signDay" placeholder="请选择" style="width: 100px;">
            <el-option label="全部" value=""/>
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"/>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-input v-model="queryList.giftName" placeholder="礼品名称" clearable/>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="query('btn')">搜索</el-button>
          <el-button type="primary" icon="el-icon-plus" @click="addOrModify()">新增</el-button>
        </el-form-item>
      </el-form>
    </el-row>
    <el-table v-loading="listLoading" :data="list" :height="tableHeight + 70" border fit highlight-current-row
              style="width: 100%;">
      <el-table-column type="index" width="50"/>
      <el-table-column prop="giftName" label="礼品名称" show-overflow-tooltip align="center"/>
      <el-table-column prop="signDay" label="签到天数" show-overflow-tooltip align="center"/>
      <el-table-column prop="itemPic" label="签到显示图片" align="center">
        <template slot-scope="scope">
          <img :src="scope.row.signPic" alt="" width="50">
        </template>
      </el-table-column>
      <el-table-column prop="itemPic" label="奖品图片" align="center">
        <template slot-scope="scope">
          <img :src="scope.row.giftPic" alt="" width="50">
        </template>
      </el-table-column>
      <el-table-column prop="" label="规则类型" show-overflow-tooltip align="center">
        <template slot-scope="scope">{{ scope.row.type == 1 ? '全部会员' : '指定会员' }}</template>
      </el-table-column>
      <el-table-column prop="userAccounts" label="中奖账号" show-overflow-tooltip align="center"/>
      <el-table-column prop="" label="状态" show-overflow-tooltip align="center">
        <template slot-scope="scope">
          <span v-if="scope.row.status" style="color: #409EFF">启用</span>
          <span v-else style="color: #F56C6C">禁用</span>
        </template>
      </el-table-column>
      <el-table-column prop="" label="创建时间" show-overflow-tooltip align="center">
        <template slot-scope="scope">{{ scope.row.createTime | timeFmtFilter }}</template>
      </el-table-column>
      <el-table-column prop="createBy" label="创建者" show-overflow-tooltip align="center"/>
      <el-table-column prop="" label="修改时间" show-overflow-tooltip align="center">
        <template slot-scope="scope">{{ scope.row.updateTime | timeFmtFilter }}</template>
      </el-table-column>
      <el-table-column prop="updateBy" label="修改账号" show-overflow-tooltip align="center"/>
      <el-table-column label="操作" align="center" width="150px">
        <template slot-scope="scope">
          <el-button type="primary" size="small" @click="addOrModify(scope.row)">修改</el-button>
          <el-button type="primary" size="small" @click="del(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <Pagination
      v-show="total>0"
      :page-sizes="[20,50,100,200,500]"
      :total="total"
      :page.sync="queryList.pageNum"
      :limit.sync="queryList.pageSize"
      @pagination="query"
    />
    <!--      新增 修改 弹窗-->
    <el-dialog :title="dialog.title" :visible.sync="dialog.dialogFormVisible" width="750px">
      <el-form :model="form" label-width="150px">
        <el-form-item label="累计签到天数:">
          <span>第{{ form.signDay }}天  </span>
          <span>输入正整数</span>
          <el-input v-model="signDay" style="width: 120px;" type="number"/>
          <span>系统自动乘以7</span>
        </el-form-item>
        <el-form-item label="奖品名称:">
          <el-input v-model="form.giftName" style="width: 200px;" clearable/>
        </el-form-item>
        <el-form-item label="签到时显示图片:">
          <el-upload
            :action="`${uploadHost}/score/signRuleCfg/uploadFile`"
            :show-file-list="false"
            :data="{siteCode: getSiteCode,fileDir:'sign'}"
            :on-success="(value)=> handleSuccess(value,'sign')"
            :on-error="onUploadFileError"
            class="avatar-uploader margin-top-15"
          >
            <img v-if="form.signPic" :src="form.signPic" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"/>
          </el-upload>
        </el-form-item>
        <el-form-item label="规则类型:">
          <el-radio v-model="form.type" :label="1">全部会员</el-radio>
          <el-radio v-model="form.type" :label="2">指定会员</el-radio>
        </el-form-item>
        <el-form-item v-if="form.type == 2">
          <el-input :rows="4" v-model="form.userAccounts" type="textarea" placeholder="请输入会员账号，用英文,隔开"
                    style="width: 300px;"/>
        </el-form-item>
        <el-form-item label="是否启用:">
          <el-radio v-model="form.status" :label="true">启用</el-radio>
          <el-radio v-model="form.status" :label="false">禁用</el-radio>
        </el-form-item>
        <el-form-item label="奖品图片:">
          <el-upload
            :action="`${uploadHost}/score/signRuleCfg/uploadFile`"
            :show-file-list="false"
            :data="{siteCode: getSiteCode,fileDir:'sign'}"
            :on-success="(value)=> handleSuccess(value,'prize')"
            :on-error="onUploadFileError"
            :before-upload="beforeAvatarUpload"
            class="avatar-uploader margin-top-15"
          >
            <img v-if="form.giftPic" :src="form.giftPic" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"/>
          </el-upload>
          <span style="position: relative;top: -44px;left: 165px;color: #C0C4CC">建议按375*185等比例大小</span>
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialog.dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addOrModifySubmit">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
    import {
        saveSecretRuleCfg,
        removeSecretRuleCfg,
        updateSecretRuleCfg,
        findSecretRuleCfgPage
    } from '@/api/modules/attendance/mystery-package'
    import Pagination from '@/components/Pagination'
    import {getAccount, getSiteCode} from '@/utils/auth'
    import {formatDate} from '@/utils'
    import { HOST_LIST } from '@/config'

    export default {
        name: 'MysteryPackage',
        components: {Pagination},
        filters: {
            timeFmtFilter(value) {
                return formatDate(new Date(value), 'yyyy-MM-dd hh:mm:ss')
            }
        },
        computed: {
            uploadHost() {
                return HOST_LIST[process.env.ENV_CONFIG]['server1']
            },
            getSiteCode() {
                return getSiteCode()
            }
        },
        data() {
            return {
                options: [// 签到天数
                    {value: 1, label: '一天'},
                    {value: 2, label: '两天'},
                    {value: 3, label: '三天'},
                    {value: 4, label: '四天'},
                    {value: 5, label: '五天'},
                    {value: 6, label: '六天'},
                    {value: 7, label: '七天'}
                ],
                queryList: {
                    signDay: '',
                    giftName: '',
                    pageSize: 20,
                    pageNum: 1
                },
                list: [],
                listLoading: false,
                total: 0,
                dialog: {
                    type: '',
                    title: '',
                    dialogFormVisible: false
                },

                dialogImageUrl: '',
                dialogVisible: false,
                disabled: false,

                signDay: 1,
                form: {
                    giftName: '',
                    signDay: '',
                    signPic: '',
                    giftPic: '',
                    type: '',
                    userAccounts: '',
                    status: true,
                    createBy: '',
                    updateBy: '',
                }
            }
        },
        watch: {
            signDay: {
                immediate: true,
                handler(val) {
                    this.form.signDay = this.signDay * 7
                }
            }
        },
        created() {
            this.query()
        },
        methods: {
            query(val) {
                if (val == 'btn') {
                    this.queryList.pageNum == 1
                }
                this.listLoading = true
                findSecretRuleCfgPage(this.queryList).then(({code, data}) => {
                    this.list = data.list
                    this.total = data.total
                }).catch(e => {
                     this.$message.error(e.msg)
                }).finally(() => (this.listLoading = false))
            },
            // 新增 修改 任务设置 按钮
            addOrModifySubmit() {
                if (this.signDay < 1) {
                    this.$message.info('请输入正确的签到天数')
                    return false
                }

                if (!this.form.giftName) {
                    this.$message.info('请输入奖品名称')
                    return false
                }
                if (!this.form.signPic) {
                    this.$message.info('请上传签到时显示图片')
                    return false
                }
                if (this.form.type == 2 && !this.form.userAccounts) {
                    this.$message.info('请输入指定会员手机号')
                    return false
                }
                if (!this.form.giftPic) {
                    this.$message.info('请上传奖品图片')
                    return false
                }

                this.form.updateBy = getAccount()
                this.form.createBy = getAccount()
                let api = null, query = this.form
                if (this.dialog.type == 'modify') {
                    api = updateSecretRuleCfg
                } else {
                    api = saveSecretRuleCfg
                }
                api(query).then(({code}) => {
                    code == 200 && this.$message.success(this.dialog.title + '成功') && this.query()
                }).catch(e => {
                    this.$message.error(e.msg)
                })
                this.dialog.dialogFormVisible = false
            },
            // 新增 修改 任务设置 弹窗
            addOrModify(row) {
                if (row) {
                    this.dialog.type = 'modify'
                    this.dialog.title = '修改神秘礼包'
                    this.signDay = row.signDay / 7
                    Object.assign(this.form,row)
                } else {
                    this.resetFrom();
                    this.dialog.type = 'add'
                    this.dialog.title = '新增神秘礼包'
                }
                this.dialog.dialogFormVisible = true
            },
            resetFrom() {
                delete this.form.id
                this.form.giftName = ''
                this.signDay = 1
                this.form.signPic = ''
                this.form.giftPic = ''
                this.form.type = 1
                this.form.userAccounts = ''
                this.form.createBy = ''
                this.form.updateBy = ''
                this.form.status = true
            },
            del(row) {
                this.$confirm(
                    `<div>
        <div style="display: flex"><span style="width: 160px;text-align: right">ID：</span>${row.id}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">签到天数：</span>${row.signDay}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">奖品名称：</span>${row.giftName}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">中奖对象：</span>${row.userAccounts}</div>
        <div style="display: flex"><span style="width: 160px;text-align: right">规则状态：</span>${row.type == 1 ? '全部会员' : '.指定会员'}</div>
      </div>`
                    , '确认删除？', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning',
                        dangerouslyUseHTMLString: true,
                        center: true
                    }).then(() => {
                    removeSecretRuleCfg(row).then(({code}) => {
                        code == 200 && this.$message.success('删除成功') && this.query()
                    }).catch(e => {
                        this.$message.error('删除失败')
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    })
                })
            },


            // 上传图片
            handleSuccess(res, item) {

                item == 'sign' ? (this.form.signPic = res.data || '') : (this.form.giftPic = res.data || '')
            },
            onUploadFileError(err, file, fileList) {
                this.$message.error(err.msg || '上传图片失败')
            },
            beforeAvatarUpload(file) {
                const isLt5M = file.size / 1024 / 1024 < 5;

                if (!isLt5M) {
                    this.$message.error('上传头像图片大小不能超过 5MB!');
                }
                return isLt5M;
            }

        }
    }
</script>

<style scoped>

</style>
